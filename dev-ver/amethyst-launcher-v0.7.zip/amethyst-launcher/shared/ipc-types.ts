export type AuthMode = "offline" | "microsoft";

export interface Account {
  name: string;
  uuid: string;
  accessToken: string;
  refreshToken?: string;
  authMode: AuthMode;
}

export type LoaderType = "vanilla" | "fabric" | "forge" | "amethyst";

export interface ServerConfig {
  id: string;
  name: string;
  address: string;
  isPrimary: boolean;
  loader: LoaderType;
  version: string;
}

export interface ServerPingResult {
  online: boolean;
  players?: { online: number; max: number };
  motd?: string;
  pingMs?: number;
  favicon?: string;
  error?: string;
}

export interface WorldEntry {
  id: string;
  name: string;
  lastPlayed: number;
  iconDataUrl?: string;
}

export interface AmethystPackManifest {
  version: string;
  minecraftVersion: string;
  loaderVersion?: string;
}

export interface AmethystPackStatus {
  configured: boolean;
  manifest: AmethystPackManifest | null;
  installedVersion: string | null;
  updateAvailable: boolean;
}

export interface AmethystSettings {
  authMode: AuthMode;
  offlineUsername: string;
  account: Account | null;
  gameDirectory: string;
  selectedVersion: string | null;
  selectedLoader: LoaderType;
  javaPath: string;
  ramMinMb: number;
  ramMaxMb: number;
  jvmArgs: string;
  showSnapshots: boolean;
  showOldVersions: boolean;
  windowWidth: number;
  windowHeight: number;
  servers: ServerConfig[];
  amethystPackSourcePath: string;
  amethystInstalledPackVersion: string | null;
}

export interface VersionEntry {
  id: string;
  type: "release" | "snapshot" | "old_beta" | "old_alpha";
  releaseTime: string;
  installed: boolean;
}

export interface InstallPlayOptions {
  versionId: string;
  loader: LoaderType;
}

export interface ProgressPayload {
  phase: string;
  task: number;
  total: number;
}

export interface ModEntry {
  filename: string;
  displayName: string;
  enabled: boolean;
  sizeKb: number;
}

export type SkinVariant = "classic" | "slim";

export interface QuickPlayTarget {
  type: "multiplayer" | "singleplayer";
  target: string;
}

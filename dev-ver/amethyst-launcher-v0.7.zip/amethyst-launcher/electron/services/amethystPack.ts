/**
 * The "Amethyst" loader isn't a public mod loader - it's our own curated
 * modpack. It's driven by a local folder (configured in Settings) shaped
 * like:
 *
 *   <source>/manifest.json   { "version": "1.4.0", "minecraftVersion": "1.21.1", "loaderVersion": "0.15.11" }
 *   <source>/mods/*.jar
 *
 * Whenever `manifest.json`'s version changes, the next sync replaces the
 * previously-installed pack mods with the new ones (tracked via a small
 * marker file so mods the player added manually are left alone).
 */

import fs from "node:fs";
import path from "node:path";
import type { AmethystPackManifest, AmethystPackStatus } from "../../shared/ipc-types";
import * as versions from "./versions";
import * as fabricInstaller from "./fabricInstaller";
import * as modsManager from "./modsManager";

const INSTALLED_MARKER_FILENAME = "amethyst-pack-installed.json";

function readManifest(sourcePath: string): AmethystPackManifest | null {
  const manifestPath = path.join(sourcePath, "manifest.json");
  if (!fs.existsSync(manifestPath)) return null;
  try {
    return JSON.parse(fs.readFileSync(manifestPath, "utf-8")) as AmethystPackManifest;
  } catch {
    return null;
  }
}

export function getStatus(sourcePath: string, installedVersion: string | null): AmethystPackStatus {
  if (!sourcePath) {
    return { configured: false, manifest: null, installedVersion, updateAvailable: false };
  }
  const manifest = readManifest(sourcePath);
  return {
    configured: true,
    manifest,
    installedVersion,
    updateAvailable: Boolean(manifest && manifest.version !== installedVersion),
  };
}

function markerPath(gameDirectory: string): string {
  return path.join(gameDirectory, INSTALLED_MARKER_FILENAME);
}

function readPreviouslyInstalledFiles(gameDirectory: string): string[] {
  try {
    return JSON.parse(fs.readFileSync(markerPath(gameDirectory), "utf-8"));
  } catch {
    return [];
  }
}

/**
 * Installs or updates the Amethyst pack: ensures the right Fabric base is
 * installed for the pack's Minecraft version, then syncs the pack's mods
 * into the instance's mods/ folder (removing only mods this pack itself
 * installed previously - anything the player added manually is untouched).
 *
 * Returns the pack's Fabric-merged custom version id to launch, plus the
 * manifest version now installed.
 */
export async function syncPack(
  gameDirectory: string,
  sourcePath: string,
  onStatus?: (status: string) => void
): Promise<{ customId: string; minecraftVersion: string; installedVersion: string }> {
  const manifest = readManifest(sourcePath);
  if (!manifest) {
    throw new Error("Couldn't find manifest.json in the configured Amethyst pack folder.");
  }

  onStatus?.(`Preparing base Fabric ${manifest.minecraftVersion} for the Amethyst pack...`);
  await versions.ensureVanillaFiles(gameDirectory, manifest.minecraftVersion);
  const { customId } = await fabricInstaller.installFabric(
    gameDirectory,
    manifest.minecraftVersion,
    manifest.loaderVersion
  );

  onStatus?.("Syncing Amethyst pack mods...");
  const sourceModsDir = path.join(sourcePath, "mods");
  const previouslyInstalled = new Set(readPreviouslyInstalledFiles(gameDirectory));
  const newlyInstalled: string[] = [];

  if (fs.existsSync(sourceModsDir)) {
    for (const filename of fs.readdirSync(sourceModsDir)) {
      if (!filename.toLowerCase().endsWith(".jar")) continue;
      modsManager.addMod(gameDirectory, path.join(sourceModsDir, filename));
      newlyInstalled.push(filename);
      previouslyInstalled.delete(filename);
    }
  }

  // Anything that was part of a previous pack sync but isn't in the new
  // manifest's mods folder anymore gets removed (stale pack mod cleanup).
  for (const stale of previouslyInstalled) {
    modsManager.removeMod(gameDirectory, stale);
  }

  fs.writeFileSync(markerPath(gameDirectory), JSON.stringify(newlyInstalled, null, 2));

  return { customId, minecraftVersion: manifest.minecraftVersion, installedVersion: manifest.version };
}

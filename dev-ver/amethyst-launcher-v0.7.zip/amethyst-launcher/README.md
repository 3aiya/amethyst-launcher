# Amethyst Launcher

A modern Minecraft launcher built with Electron, React, TypeScript, and Tailwind CSS.
Dark theme, `#FF00FF` accent, Modrinth-inspired sidebar layout.

## Stack

| Layer          | Tech                                              |
| -------------- | -------------------------------------------------- |
| Frontend       | Electron + React + TypeScript                      |
| Backend        | Node.js (Electron main process)                    |
| Minecraft core | `minecraft-launcher-core` (MCLC) + `msmc` for auth  |
| Database       | SQLite (`better-sqlite3`) for local settings        |
| Auto update    | `electron-updater`                                  |
| Installer      | `electron-builder`                                  |
| UI             | Tailwind CSS v4 + Framer Motion + lucide-react      |

## Features

- **Version manager** — release/snapshot/old-version listing straight from
  Mojang's manifest, with installed versions marked.
- **Both login modes** — offline profiles, and real Microsoft login through
  `msmc`'s built-in Electron popup flow (uses Mojang's own public client ID,
  so **no Azure app registration needed** — unlike a lot of DIY launchers).
- **Java auto-detect / auto-download** — downloads Mojang's own per-version
  Java runtime automatically; falls back to system Java.
- **Mods** — Fabric installs via a version-json merge (MCLC has no native
  Fabric support, so this recreates what the official launcher does
  internally); Forge installs via MCLC's built-in ForgeWrapper integration.
  Mods folder manager: add/remove/enable/disable `.jar`s.
- **Skins** — upload/reset via the official Minecraft Services API
  (Microsoft accounts only).
- **Discord Rich Presence** — shows "Amethyst Launcher" / "Playing
  &lt;version&gt;" on your Discord profile while the game runs, idle
  otherwise. See [Discord Rich Presence setup](#discord-rich-presence-setup)
  below.
- **Servers & worlds panel** — a featured card for your primary server plus
  a grid of other servers and singleplayer worlds, each live-pinged for
  status/player count. Hitting Play quick-plays straight into that server or
  world via MCLC's native `quickPlay` (Minecraft 1.20+; needs the identifier
  a server/world expects — IP for servers, save folder name for worlds).
- **Amethyst Loader** — a 4th loader option for our own curated modpack.
  Point it at a local folder (Settings -> Amethyst modpack) and it installs/
  updates automatically whenever that folder's `manifest.json` version
  changes. See [Amethyst Loader setup](#amethyst-loader-setup) below.
- **Local settings in SQLite**, no cloud sync, no telemetry.

## Requirements

- Node.js 20+
- A legally owned copy of Minecraft (for Microsoft login / online play)

## Setup

```bash
npm install
npm run dev
```

`npm install` also runs `electron-rebuild` (via `postinstall`) to recompile
`better-sqlite3`'s native binary for Electron's Node ABI — this needs
internet access the first time (it downloads Electron's headers).

`npm run dev` starts the Vite dev server and Electron together with hot
reload for the renderer.

## Building a release

```bash
npm run dist
```

This runs the Vite + TypeScript builds and then `electron-builder`, producing
an installer under `release/` (NSIS on Windows, DMG on macOS, AppImage on
Linux — see the `build` block in `package.json`).

## How Microsoft sign-in works

Unlike launchers built around `minecraft-launcher-lib` (Python) or similar,
`msmc` ships with Mojang's own official client ID baked in, plus a built-in
Electron popup (`Auth.launch("electron")`) that handles the whole
Microsoft → Xbox → Minecraft token chain for you. No Azure app registration,
no manual redirect-URL copy-pasting — click "Sign in with Microsoft," log in
in the popup, done.

## Amethyst Loader setup

The "Amethyst Loader" isn't a public mod loader - it's our own curated
modpack, hosted as a plain local folder (no server needed). Point it at
that folder from **Settings -> Amethyst modpack -> Pack source folder**.

The folder needs to look like:

```
<your-pack-folder>/
├── manifest.json
└── mods/
    ├── some-mod.jar
    └── another-mod.jar
```

`manifest.json`:

```json
{
  "version": "1.4.0",
  "minecraftVersion": "1.21.1",
  "loaderVersion": "0.15.11"
}
```

- `version` is whatever versioning scheme you want for the pack itself
  (semver, a date, a build number — just needs to change when the pack
  updates).
- `minecraftVersion` / `loaderVersion` pin the Fabric base the pack installs
  automatically.

**Auto-update**: every time the launcher checks pack status (on start, and
after every sync), it re-reads `manifest.json` fresh — so bumping `version`
in that file and dropping in new jars under `mods/` is all it takes for the
launcher to show "Update available" and sync the new set next time you hit
Sync (or Play with the Amethyst loader selected). Mods the pack itself
installed previously are cleanly swapped out; anything you added manually to
the mods folder is left alone.

Selecting **Amethyst** as the loader on the Play tab locks the version
picker (the pack's manifest already pins the Minecraft version) and syncs +
launches in one go.

## Discord Rich Presence setup

Rich Presence works out of the box in "off" mode - it silently does nothing
until configured, so nothing breaks if you skip this. To turn it on, edit
**`electron/services/discordConfig.ts`** (the only file you need to touch):

```ts
export const DISCORD_CLIENT_ID = "PUT_YOUR_DISCORD_APPLICATION_ID_HERE";
export const DISCORD_LARGE_IMAGE_KEY = "amethyst_logo_placeholder";
```

1. Create an application at <https://discord.com/developers/applications>
   and copy its **Application ID** into `DISCORD_CLIENT_ID`.
2. Under that application's **Rich Presence -> Art Assets**, upload your
   `image.png` and give it an asset key (e.g. `amethyst_logo`). Copy that
   same key into `DISCORD_LARGE_IMAGE_KEY`.

That's the only place either value lives, so swapping in your final image
later is a one-line change.

Behavior:
- Connects automatically on launcher start; shows "Amethyst Launcher / In
  the launcher" once connected.
- Switches to "Amethyst Launcher / Playing &lt;version&gt;" (or
  "Playing Fabric 1.21.1" / "Playing Forge 1.20.1" for modded) right after
  the game launches, and back to idle when it closes.
- If Discord isn't running (or isn't installed), it fails silently and
  retries every 15 seconds in the background - so it picks up automatically
  if you open Discord after the launcher.
- Cleanly disconnects and clears the activity on quit.

## Project structure

```
amethyst-launcher/
├── electron/                   # Main process (compiled to dist-electron/)
│   ├── main.ts                  # Window creation, auto-update, bootstrap
│   ├── preload.ts                # contextBridge -> window.amethyst API
│   ├── ipc.ts                    # All ipcMain.handle channels
│   ├── db.ts                     # SQLite-backed settings store
│   └── services/
│       ├── auth.ts                # Offline + Microsoft (msmc) login
│       ├── versions.ts            # Mojang manifest + installed versions
│       ├── javaManager.ts         # Java detect/auto-download
│       ├── fabricInstaller.ts     # Fabric version-json merge installer
│       ├── forgeInstaller.ts      # Forge installer jar download (+ MCLC's ForgeWrapper)
│       ├── modsManager.ts         # mods/ folder management
│       ├── skinManager.ts         # Minecraft Services skin API
│       ├── discordConfig.ts       # Discord app id + asset key (edit here)
│       ├── discordRpc.ts          # Discord Rich Presence lifecycle
│       ├── serverPing.ts          # Raw Server List Ping protocol (status/players)
│       ├── worlds.ts              # Reads saves/ folder + level.dat (NBT) for world names
│       ├── amethystPack.ts        # Amethyst modpack manifest sync
│       └── launcher.ts            # Orchestrates install + MCLC launch
├── src/                         # Renderer (React + Tailwind + Framer Motion)
│   ├── App.tsx
│   ├── components/
│   │   ├── TitleBar.tsx            # Custom frameless window titlebar
│   │   ├── Sidebar.tsx              # Nav with animated active indicator
│   │   ├── PlayPage.tsx
│   │   ├── ServersSection.tsx       # Featured server + servers/worlds grid
│   │   ├── ModsPage.tsx
│   │   ├── SkinsPage.tsx
│   │   ├── SettingsPage.tsx
│   │   └── LoginModal.tsx
│   └── types/global.d.ts          # window.amethyst typings
└── shared/ipc-types.ts          # Types shared by main + renderer
```

## Notes

- Game files install to `<userData>/minecraft` by default (changeable in
  Settings) — on Linux that's `~/.config/amethyst-launcher/minecraft`.
- Offline mode only works with game files you already legally own, exactly
  like the official launcher's LAN/offline play — this launcher provides no
  way to play without owning the game.

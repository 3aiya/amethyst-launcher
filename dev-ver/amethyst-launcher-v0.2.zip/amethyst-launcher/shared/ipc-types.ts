export type AuthMode = "offline" | "microsoft";

export interface Account {
  name: string;
  uuid: string;
  accessToken: string;
  refreshToken?: string;
  authMode: AuthMode;
}

export interface AmethystSettings {
  authMode: AuthMode;
  offlineUsername: string;
  account: Account | null;
  gameDirectory: string;
  selectedVersion: string | null;
  selectedLoader: "vanilla" | "fabric" | "forge";
  javaPath: string;
  ramMinMb: number;
  ramMaxMb: number;
  jvmArgs: string;
  showSnapshots: boolean;
  showOldVersions: boolean;
  windowWidth: number;
  windowHeight: number;
}

export interface VersionEntry {
  id: string;
  type: "release" | "snapshot" | "old_beta" | "old_alpha";
  releaseTime: string;
  installed: boolean;
}

export interface InstallPlayOptions {
  versionId: string;
  loader: "vanilla" | "fabric" | "forge";
}

export interface ProgressPayload {
  phase: string;
  task: number;
  total: number;
}

export interface ModEntry {
  filename: string;
  displayName: string;
  enabled: boolean;
  sizeKb: number;
}

export type SkinVariant = "classic" | "slim";

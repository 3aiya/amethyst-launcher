import { motion } from "framer-motion";
import { FolderOpen, Plus, Trash2, ToggleLeft, ToggleRight } from "lucide-react";
import type { ModEntry } from "../types/global";

interface ModsPageProps {
  mods: ModEntry[];
  selected: string | null;
  onSelect: (filename: string) => void;
  onAdd: () => void;
  onRemove: () => void;
  onToggle: () => void;
  onOpenFolder: () => void;
}

export default function ModsPage({ mods, selected, onSelect, onAdd, onRemove, onToggle, onOpenFolder }: ModsPageProps) {
  return (
    <div className="flex h-full flex-col gap-6 p-8">
      <div>
        <h1 className="text-2xl font-bold text-zinc-50">Mods</h1>
        <p className="text-sm text-zinc-500">
          Applies to the current game directory - use Fabric or Forge on the Play tab for mods
          to actually load.
        </p>
      </div>

      <div className="flex-1 overflow-y-auto rounded-2xl border border-border bg-bg-elevated p-2">
        {mods.length === 0 && (
          <p className="p-6 text-center text-sm text-zinc-600">No mods yet - add a .jar to get started.</p>
        )}
        {mods.map((mod) => (
          <motion.button
            key={mod.filename}
            layout
            onClick={() => onSelect(mod.filename)}
            className={`mb-1 flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${
              selected === mod.filename ? "bg-accent/15 text-accent" : "text-zinc-200 hover:bg-bg-card-hover"
            }`}
          >
            <span className="truncate">{mod.displayName}</span>
            <span className="ml-3 shrink-0 text-xs text-zinc-500">
              {mod.sizeKb} KB {!mod.enabled && "· disabled"}
            </span>
          </motion.button>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          onClick={onAdd}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent transition-colors"
        >
          <Plus size={15} /> Add mod
        </button>
        <button
          onClick={onToggle}
          disabled={!selected}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent disabled:opacity-40 transition-colors"
        >
          {mods.find((m) => m.filename === selected)?.enabled === false ? (
            <ToggleLeft size={15} />
          ) : (
            <ToggleRight size={15} />
          )}
          Enable/disable
        </button>
        <button
          onClick={onRemove}
          disabled={!selected}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-red-400 hover:border-red-400 disabled:opacity-40 transition-colors"
        >
          <Trash2 size={15} /> Remove
        </button>
        <div className="flex-1" />
        <button
          onClick={onOpenFolder}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent transition-colors"
        >
          <FolderOpen size={15} /> Open folder
        </button>
      </div>
    </div>
  );
}

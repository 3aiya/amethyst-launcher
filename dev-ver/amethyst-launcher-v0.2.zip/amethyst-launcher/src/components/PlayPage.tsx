import { RefreshCw } from "lucide-react";
import type { VersionEntry } from "../types/global";

interface PlayPageProps {
  versions: VersionEntry[];
  loadingVersions: boolean;
  selectedVersion: string;
  onSelectVersion: (id: string) => void;
  loader: "vanilla" | "fabric" | "forge";
  onSelectLoader: (loader: "vanilla" | "fabric" | "forge") => void;
  showSnapshots: boolean;
  showOldVersions: boolean;
  onToggleSnapshots: (value: boolean) => void;
  onToggleOldVersions: (value: boolean) => void;
  onRefresh: () => void;
}

export default function PlayPage({
  versions,
  loadingVersions,
  selectedVersion,
  onSelectVersion,
  loader,
  onSelectLoader,
  showSnapshots,
  showOldVersions,
  onToggleSnapshots,
  onToggleOldVersions,
  onRefresh,
}: PlayPageProps) {
  return (
    <div className="flex h-full flex-col gap-6 p-8">
      <div>
        <h1 className="text-2xl font-bold text-zinc-50">Play</h1>
        <p className="text-sm text-zinc-500">Choose a version and mod loader, then launch.</p>
      </div>

      <div className="rounded-2xl border border-border bg-bg-card p-5">
        <div className="mb-4">
          <label className="mb-1.5 block text-xs font-medium text-zinc-400">Loader</label>
          <div className="flex gap-2">
            {(["vanilla", "fabric", "forge"] as const).map((l) => (
              <button
                key={l}
                onClick={() => onSelectLoader(l)}
                className={`flex-1 rounded-lg border py-2 text-sm font-medium capitalize transition-colors ${
                  loader === l
                    ? "border-accent bg-accent/15 text-accent"
                    : "border-border-light text-zinc-400 hover:text-zinc-100"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-4">
          <label className="mb-1.5 block text-xs font-medium text-zinc-400">Version</label>
          <div className="flex gap-2">
            <select
              value={selectedVersion}
              onChange={(e) => onSelectVersion(e.target.value)}
              className="flex-1 rounded-lg border border-border-light bg-bg-elevated px-3 py-2 text-sm text-zinc-100 outline-none focus:border-accent"
            >
              <option value="">Select a version...</option>
              {versions.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.id} {v.installed ? "(installed)" : ""}
                </option>
              ))}
            </select>
            <button
              onClick={onRefresh}
              className="flex items-center gap-1.5 rounded-lg border border-border-light px-3 py-2 text-sm text-zinc-300 hover:border-accent hover:text-accent transition-colors"
            >
              <RefreshCw size={14} className={loadingVersions ? "animate-spin" : ""} />
              Refresh
            </button>
          </div>
        </div>

        <div className="flex gap-4 text-sm text-zinc-400">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={showSnapshots}
              onChange={(e) => onToggleSnapshots(e.target.checked)}
              className="accent-[--color-accent]"
            />
            Show snapshots
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={showOldVersions}
              onChange={(e) => onToggleOldVersions(e.target.checked)}
              className="accent-[--color-accent]"
            />
            Show old alpha/beta
          </label>
        </div>
      </div>

      <div className="flex-1" />
    </div>
  );
}

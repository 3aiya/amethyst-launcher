# Amethyst Launcher

A modern Minecraft launcher built with Electron, React, TypeScript, and Tailwind CSS.
Dark theme, `#FF00FF` accent, Modrinth-inspired sidebar layout.

## Stack

| Layer          | Tech                                              |
| -------------- | -------------------------------------------------- |
| Frontend       | Electron + React + TypeScript                      |
| Backend        | Node.js (Electron main process)                    |
| Minecraft core | `minecraft-launcher-core` (MCLC) + `msmc` for auth  |
| Database       | SQLite (`better-sqlite3`) for local settings        |
| Auto update    | `electron-updater`                                  |
| Installer      | `electron-builder`                                  |
| UI             | Tailwind CSS v4 + Framer Motion + lucide-react      |

## Features

- **Version manager** — release/snapshot/old-version listing straight from
  Mojang's manifest, with installed versions marked.
- **Both login modes** — offline profiles, and real Microsoft login through
  `msmc`'s built-in Electron popup flow (uses Mojang's own public client ID,
  so **no Azure app registration needed** — unlike a lot of DIY launchers).
- **Java auto-detect / auto-download** — downloads Mojang's own per-version
  Java runtime automatically; falls back to system Java.
- **Mods** — Fabric installs via a version-json merge (MCLC has no native
  Fabric support, so this recreates what the official launcher does
  internally); Forge installs via MCLC's built-in ForgeWrapper integration.
  Mods folder manager: add/remove/enable/disable `.jar`s.
- **Skins** — upload/reset via the official Minecraft Services API
  (Microsoft accounts only).
- **Local settings in SQLite**, no cloud sync, no telemetry.

## Requirements

- Node.js 20+
- A legally owned copy of Minecraft (for Microsoft login / online play)

## Setup

```bash
npm install
npm run dev
```

`npm install` also runs `electron-rebuild` (via `postinstall`) to recompile
`better-sqlite3`'s native binary for Electron's Node ABI — this needs
internet access the first time (it downloads Electron's headers).

`npm run dev` starts the Vite dev server and Electron together with hot
reload for the renderer.

## Building a release

```bash
npm run dist
```

This runs the Vite + TypeScript builds and then `electron-builder`, producing
an installer under `release/` (NSIS on Windows, DMG on macOS, AppImage on
Linux — see the `build` block in `package.json`).

## How Microsoft sign-in works

Unlike launchers built around `minecraft-launcher-lib` (Python) or similar,
`msmc` ships with Mojang's own official client ID baked in, plus a built-in
Electron popup (`Auth.launch("electron")`) that handles the whole
Microsoft → Xbox → Minecraft token chain for you. No Azure app registration,
no manual redirect-URL copy-pasting — click "Sign in with Microsoft," log in
in the popup, done.

## Project structure

```
amethyst-launcher/
├── electron/                   # Main process (compiled to dist-electron/)
│   ├── main.ts                  # Window creation, auto-update, bootstrap
│   ├── preload.ts                # contextBridge -> window.amethyst API
│   ├── ipc.ts                    # All ipcMain.handle channels
│   ├── db.ts                     # SQLite-backed settings store
│   └── services/
│       ├── auth.ts                # Offline + Microsoft (msmc) login
│       ├── versions.ts            # Mojang manifest + installed versions
│       ├── javaManager.ts         # Java detect/auto-download
│       ├── fabricInstaller.ts     # Fabric version-json merge installer
│       ├── forgeInstaller.ts      # Forge installer jar download (+ MCLC's ForgeWrapper)
│       ├── modsManager.ts         # mods/ folder management
│       ├── skinManager.ts         # Minecraft Services skin API
│       └── launcher.ts            # Orchestrates install + MCLC launch
├── src/                         # Renderer (React + Tailwind + Framer Motion)
│   ├── App.tsx
│   ├── components/
│   │   ├── TitleBar.tsx            # Custom frameless window titlebar
│   │   ├── Sidebar.tsx              # Nav with animated active indicator
│   │   ├── PlayPage.tsx
│   │   ├── ModsPage.tsx
│   │   ├── SkinsPage.tsx
│   │   ├── SettingsPage.tsx
│   │   └── LoginModal.tsx
│   └── types/global.d.ts          # window.amethyst typings
└── shared/ipc-types.ts          # Types shared by main + renderer
```

## Notes

- Game files install to `<userData>/minecraft` by default (changeable in
  Settings) — on Linux that's `~/.config/amethyst-launcher/minecraft`.
- Offline mode only works with game files you already legally own, exactly
  like the official launcher's LAN/offline play — this launcher provides no
  way to play without owning the game.

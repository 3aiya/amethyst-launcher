import { Client } from "minecraft-launcher-core";
import type { AmethystSettings, ProgressPayload } from "../../shared/ipc-types";
import * as versions from "./versions";
import * as javaManager from "./javaManager";
import * as fabricInstaller from "./fabricInstaller";
import * as forgeInstaller from "./forgeInstaller";
import { toMclcUser } from "./auth";

export interface LaunchCallbacks {
  onStatus: (status: string) => void;
  onProgress: (progress: ProgressPayload) => void;
  onLog: (line: string) => void;
  onClose: (code: number) => void;
}

export async function installAndLaunch(
  settings: AmethystSettings,
  versionId: string,
  loader: "vanilla" | "fabric" | "forge",
  callbacks: LaunchCallbacks
): Promise<void> {
  const gameDirectory = settings.gameDirectory;
  if (!settings.account) throw new Error("No account signed in.");

  callbacks.onStatus(`Preparing ${versionId}...`);

  const clientJson = await versions.readVersionClientJson(gameDirectory, versionId).catch(() => null);
  const javaComponent = clientJson?.javaVersion?.component ?? "jre-legacy";

  callbacks.onStatus("Checking Java runtime...");
  const javaPath = await javaManager.ensureJavaFor(gameDirectory, javaComponent, settings.javaPath, (p) =>
    callbacks.onProgress({ phase: "java", task: p.task, total: p.total })
  );

  let versionCustom: string | undefined;
  let minecraftJarOverride: string | undefined;
  let versionJsonOverride: string | undefined;
  let forgeInstallerPath: string | undefined;

  if (loader === "fabric") {
    callbacks.onStatus("Downloading vanilla files Fabric depends on...");
    await versions.ensureVanillaFiles(gameDirectory, versionId);

    callbacks.onStatus("Installing Fabric loader...");
    const result = await fabricInstaller.installFabric(gameDirectory, versionId);
    versionCustom = result.customId;
    minecraftJarOverride = result.vanillaJarPath;
    versionJsonOverride = result.mergedJsonPath;
  } else if (loader === "forge") {
    callbacks.onStatus("Looking up matching Forge build...");
    const forgeVersion = await forgeInstaller.findRecommendedForgeVersion(versionId);
    if (!forgeVersion) throw new Error(`No Forge build found for ${versionId}.`);

    callbacks.onStatus(`Downloading Forge ${forgeVersion} installer...`);
    forgeInstallerPath = await forgeInstaller.downloadForgeInstaller(gameDirectory, versionId, forgeVersion);
  }

  callbacks.onStatus("Launching Minecraft...");

  const extraArgs = settings.jvmArgs.trim() ? settings.jvmArgs.trim().split(/\s+/) : [];

  const client = new Client();
  client.on("progress", (p: any) =>
    callbacks.onProgress({ phase: p.type, task: p.task, total: p.total })
  );
  client.on("debug", (msg: string) => callbacks.onLog(`[debug] ${msg}`));
  client.on("data", (msg: string) => callbacks.onLog(msg));
  client.on("close", (code: number) => callbacks.onClose(code));

  await client.launch({
    root: gameDirectory,
    version: { number: versionId, type: "release", custom: versionCustom },
    memory: { min: `${settings.ramMinMb}M`, max: `${settings.ramMaxMb}M` },
    javaPath,
    customArgs: extraArgs,
    forge: forgeInstallerPath,
    window: { width: settings.windowWidth, height: settings.windowHeight },
    authorization: toMclcUser(settings.account) as any,
    overrides: {
      minecraftJar: minecraftJarOverride,
      versionJson: versionJsonOverride,
    },
  });
}

import { app, BrowserWindow } from "electron";
import path from "node:path";
import { autoUpdater } from "electron-updater";
import { initDatabase, getSettings } from "./db";
import { registerIpcHandlers } from "./ipc";

const isDev = process.env.NODE_ENV === "development";

let mainWindow: BrowserWindow | null = null;

function createWindow(): void {
  const settings = getSettings();

  mainWindow = new BrowserWindow({
    width: settings.windowWidth,
    height: settings.windowHeight,
    minWidth: 900,
    minHeight: 560,
    frame: false,
    backgroundColor: "#0d0d10",
    titleBarStyle: "hidden",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  if (isDev) {
    mainWindow.loadURL("http://localhost:5173");
    mainWindow.webContents.openDevTools({ mode: "detach" });
  } else {
    mainWindow.loadFile(path.join(__dirname, "..", "..", "dist", "index.html"));
  }

  registerIpcHandlers(mainWindow);

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  initDatabase();
  createWindow();

  if (!isDev && app.isPackaged) {
    autoUpdater.checkForUpdatesAndNotify().catch(() => {
      // Silently ignore update-check failures (e.g. offline).
    });
  }

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

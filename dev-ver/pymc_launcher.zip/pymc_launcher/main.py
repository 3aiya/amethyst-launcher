import sys

from PyQt6.QtWidgets import QApplication

from ui.main_window import MainWindow
from ui.theme import THEME_QSS


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PyMC Launcher")
    app.setStyleSheet(THEME_QSS)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

# PyMC Launcher

A full-featured, open-source Minecraft launcher written in Python + PyQt6.

## Features

- **Version manager** — browse and install any release (optionally snapshots
  and old alpha/beta versions), backed by Mojang's official version manifest.
- **Both login modes** — offline profiles (singleplayer/LAN/offline servers)
  and real Microsoft account login (multiplayer, Realms, skins).
- **Java auto-detect / auto-download** — automatically downloads the correct
  Mojang-provided Java runtime per version, no manual Java install needed.
- **Mod support** — install Fabric or Forge automatically, then manage the
  `mods/` folder (add, remove, enable/disable) from the Mods tab.
- **Skins** — upload a custom skin or reset to default (Microsoft accounts
  only, since offline accounts have no real Mojang profile).

## Requirements

- Python 3.10+
- A legally owned copy of Minecraft (for Microsoft login / online play)

## Setup

```bash
python -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Setting up Microsoft login (optional, only needed for online play)

Microsoft requires every application to log in with its own registered
**Azure AD app**. This is free and takes about 5 minutes:

1. Go to <https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/CreateApplicationBlade>
   (sign in with any Microsoft account).
2. Name it anything (e.g. "My PyMC Launcher").
3. Under **Supported account types**, choose
   *"Accounts in any organizational directory and personal Microsoft accounts"*.
4. Under **Redirect URI**, choose platform **"Public client/native (mobile & desktop)"**
   and enter:
   ```
   https://login.microsoftonline.com/common/oauth2/nativeclient
   ```
5. Click **Register**. Copy the **Application (client) ID** from the overview page.
6. Go to **Authentication** in the left sidebar and make sure
   **"Allow public client flows"** is set to **Yes**. Save.
7. Set that client ID in one of these ways:
   - Edit `core/auth.py` and set `CLIENT_ID = "your-client-id-here"`, or
   - Set an environment variable before running:
     ```bash
     export MC_LAUNCHER_CLIENT_ID="your-client-id-here"   # Windows: set MC_LAUNCHER_CLIENT_ID=...
     python main.py
     ```

Offline mode works immediately with no setup — just pick the "Offline" tab
on the sign-in screen.

## How the Microsoft sign-in flow works

Because this is a desktop app without a running web server, sign-in uses the
"copy the redirect URL back" method used by several open-source launchers:

1. Click **Open Microsoft login** — this opens your browser to the real
   Microsoft sign-in page.
2. Sign in normally (2FA etc. all handled by Microsoft, never by this app).
3. The browser lands on a page that may look blank, or show an error graphic
   — that's expected, since there's no server listening at that address.
   What matters is the **URL** in the address bar, which now contains an
   authorization code.
4. Copy that full URL and paste it into the launcher, then click
   **Complete sign-in**.

Your Microsoft password is never seen by this app — only Microsoft's own
login page ever sees it.

## Project structure

```
pymc_launcher/
├── main.py                 # Entry point
├── core/
│   ├── config.py            # Persistent settings (~/.pymc_launcher/config.json)
│   ├── auth.py               # Offline + Microsoft login
│   ├── launcher.py           # Version listing/install/launch (vanilla, Forge, Fabric)
│   ├── java_manager.py       # Java runtime detection & auto-download
│   ├── mods_manager.py       # mods/ folder management
│   └── skin_manager.py       # Minecraft Services skin API
└── ui/
    ├── main_window.py        # Play / Mods / Skins / Settings tabs
    ├── login_dialog.py       # Sign-in dialog
    └── workers.py             # Background QThread workers (installs, launches, login)
```

## Notes

- Game files install to `~/.pymc_launcher/minecraft` by default (changeable
  in Settings).
- This launcher does not, and will never, provide a way to play without
  owning the game — offline mode only works with game files you already
  legally own, exactly like the official launcher's LAN/offline play.
- Built on top of the [minecraft-launcher-lib](https://github.com/JakobDev/minecraft-launcher-lib)
  library, which handles the low-level Mojang API interactions.

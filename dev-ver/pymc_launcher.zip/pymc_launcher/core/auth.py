"""
Authentication for both supported modes:

  * Offline mode: generates a deterministic fake UUID from a username.
    Works for singleplayer / LAN / offline-mode servers with a legally
    owned copy of the game. It does NOT work for realms or servers that
    require Mojang/Xbox authentication.

  * Microsoft mode: real login through Microsoft/Xbox/Minecraft services,
    using the official OAuth2 "authorization code" flow. This requires
    YOUR OWN Azure AD application client ID (free to create) because
    Microsoft ties every login to a registered app. See README.md for
    the 5-minute setup steps.
"""

import os
import uuid

import minecraft_launcher_lib as mll

# Set your own Azure App client ID here, or via the MC_LAUNCHER_CLIENT_ID
# environment variable. See README.md -> "Setting up Microsoft login".
CLIENT_ID = os.environ.get("MC_LAUNCHER_CLIENT_ID", "")

# This redirect URI is a special Microsoft-provided address for public
# (installed) apps: it doesn't need a running web server, it just displays
# the resulting URL in the browser's address bar for the user to copy back.
REDIRECT_URI = "https://login.microsoftonline.com/common/oauth2/nativeclient"


class AuthError(Exception):
    pass


def offline_login(username: str) -> dict:
    username = (username or "").strip()
    if not username:
        raise AuthError("Username cannot be empty.")
    if len(username) > 25:
        raise AuthError("Username is too long.")

    offline_uuid = uuid.uuid3(uuid.NAMESPACE_DNS, "OfflinePlayer:" + username)
    return {
        "name": username,
        "id": str(offline_uuid).replace("-", ""),
        "access_token": "0",
        "refresh_token": None,
        "auth_mode": "offline",
    }


def get_microsoft_login_url() -> str:
    if not CLIENT_ID:
        raise AuthError(
            "Microsoft login is not configured yet.\n"
            "Set your Azure app Client ID in core/auth.py or the "
            "MC_LAUNCHER_CLIENT_ID environment variable.\n"
            "See README.md for setup instructions."
        )
    return mll.microsoft_account.get_login_url(CLIENT_ID, REDIRECT_URI)


def complete_microsoft_login(redirect_url: str) -> dict:
    """
    `redirect_url` is the full URL the browser lands on after the user
    signs in (the one containing '?code=...'), pasted back by the user.
    """
    if not CLIENT_ID:
        raise AuthError("Microsoft login is not configured. See README.md.")

    auth_code = mll.microsoft_account.get_auth_code_from_url(redirect_url)
    if not auth_code:
        raise AuthError(
            "That doesn't look like a valid redirect URL. Make sure you "
            "copied the full address bar contents after signing in."
        )

    try:
        result = mll.microsoft_account.complete_login(
            CLIENT_ID, None, REDIRECT_URI, auth_code
        )
    except Exception as exc:  # noqa: BLE001 - surface any auth chain failure
        raise AuthError(f"Microsoft login failed: {exc}") from exc

    if result.get("error"):
        raise AuthError(result.get("errorMessage", "Unknown Microsoft login error."))

    return {
        "name": result["name"],
        "id": result["id"],
        "access_token": result["access_token"],
        "refresh_token": result.get("refresh_token"),
        "auth_mode": "microsoft",
    }


def refresh_microsoft_login(refresh_token: str) -> dict:
    if not CLIENT_ID:
        raise AuthError("Microsoft login is not configured. See README.md.")
    try:
        result = mll.microsoft_account.complete_refresh(
            CLIENT_ID, None, REDIRECT_URI, refresh_token
        )
    except Exception as exc:  # noqa: BLE001
        raise AuthError(f"Could not refresh Microsoft session: {exc}") from exc

    return {
        "name": result["name"],
        "id": result["id"],
        "access_token": result["access_token"],
        "refresh_token": result.get("refresh_token", refresh_token),
        "auth_mode": "microsoft",
    }

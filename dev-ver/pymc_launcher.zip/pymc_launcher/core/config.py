"""
Handles reading/writing the launcher's persistent settings.
Everything is stored as plain JSON in ~/.pymc_launcher/config.json
"""

import json
import os

APP_DIR = os.path.join(os.path.expanduser("~"), ".pymc_launcher")
CONFIG_FILE = os.path.join(APP_DIR, "config.json")

DEFAULT_CONFIG = {
    # Account
    "auth_mode": "offline",        # "offline" or "microsoft"
    "offline_username": "Player",
    "ms_account": None,            # {"name", "id", "access_token", "refresh_token"}

    # Game
    "game_directory": os.path.join(APP_DIR, "minecraft"),
    "selected_version": None,
    "selected_loader": "vanilla",  # "vanilla", "forge", "fabric"

    # Java / performance
    "java_path": "",               # empty = auto-detect
    "ram_min_mb": 1024,
    "ram_max_mb": 2048,
    "jvm_args": "",

    # Version list filters
    "show_snapshots": False,
    "show_old_versions": False,

    # Window
    "resolution_width": 1280,
    "resolution_height": 720,
}


def load_config() -> dict:
    os.makedirs(APP_DIR, exist_ok=True)
    if not os.path.exists(CONFIG_FILE):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        data = {}

    merged = DEFAULT_CONFIG.copy()
    merged.update(data)
    return merged


def save_config(config: dict) -> None:
    os.makedirs(APP_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def ensure_game_directory(config: dict) -> str:
    game_dir = config.get("game_directory") or os.path.join(APP_DIR, "minecraft")
    os.makedirs(game_dir, exist_ok=True)
    return game_dir

"""
Figures out which Java runtime to launch a given Minecraft version with,
downloading Mojang's own prebuilt runtime automatically when needed
(the same runtimes the official launcher uses - no manual Java install
required).
"""

import shutil

import minecraft_launcher_lib as mll


def detect_system_java() -> str | None:
    """Return a system 'java' executable path if one is on PATH, else None."""
    guessed = mll.utils.get_java_executable()
    if guessed and shutil.which(guessed):
        return shutil.which(guessed)
    return shutil.which("java") or shutil.which("javaw")


def required_runtime_component(version_id: str, minecraft_directory: str) -> str:
    """Read the version's client json to find which Mojang runtime component
    it wants (e.g. 'jre-legacy', 'java-runtime-gamma')."""
    client_json = mll.runtime.get_client_json(version_id, minecraft_directory)
    java_version = client_json.get("javaVersion", {})
    return java_version.get("component", "jre-legacy")


def get_runtime_java_path(component: str, minecraft_directory: str) -> str | None:
    return mll.runtime.get_executable_path(component, minecraft_directory)


def ensure_java_for_version(version_id: str, minecraft_directory: str, callback=None) -> str:
    """
    Makes sure a working Java executable is available for `version_id`.
    Prefers Mojang's own managed runtime (matches what the official launcher
    would use); downloads it on first use. Falls back to system Java if the
    managed runtime can't be resolved. Returns a path to the java executable.
    """
    component = required_runtime_component(version_id, minecraft_directory)

    existing = get_runtime_java_path(component, minecraft_directory)
    if existing:
        return existing

    mll.runtime.install_jvm_runtime(component, minecraft_directory, callback=callback)

    installed = get_runtime_java_path(component, minecraft_directory)
    if installed:
        return installed

    system_java = detect_system_java()
    if system_java:
        return system_java

    raise RuntimeError(
        "Could not find or download a Java runtime. Please install Java "
        "manually and set its path in Settings."
    )

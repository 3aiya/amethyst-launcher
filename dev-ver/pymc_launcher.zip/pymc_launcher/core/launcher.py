"""
Core game logic: listing versions, installing them (vanilla/Forge/Fabric),
and launching the game as a subprocess.
"""

import subprocess

import minecraft_launcher_lib as mll

from core import java_manager


def get_available_versions(show_snapshots: bool, show_old_versions: bool) -> list[dict]:
    versions = mll.utils.get_version_list()
    result = []
    for v in versions:
        if v["type"] == "release":
            result.append(v)
        elif v["type"] == "snapshot" and show_snapshots:
            result.append(v)
        elif v["type"] in ("old_beta", "old_alpha") and show_old_versions:
            result.append(v)
    return result


def get_installed_versions(minecraft_directory: str) -> list[dict]:
    return mll.utils.get_installed_versions(minecraft_directory)


def get_latest_fabric_loader() -> str:
    return mll.fabric.get_latest_loader_version()


def find_forge_version(vanilla_version: str) -> str | None:
    """Best-effort match of a Forge build for a vanilla version, or None."""
    try:
        return mll.forge.find_forge_version(vanilla_version)
    except Exception:  # noqa: BLE001
        return None


def install_vanilla(version_id: str, minecraft_directory: str, callback: dict) -> None:
    mll.install.install_minecraft_version(version_id, minecraft_directory, callback=callback)


def install_fabric_loader(version_id: str, minecraft_directory: str, callback: dict,
                           loader_version: str | None = None) -> None:
    mll.fabric.install_fabric(
        version_id, minecraft_directory, loader_version=loader_version, callback=callback
    )


def install_forge_loader(minecraft_directory: str, callback: dict, forge_version: str) -> None:
    if not mll.forge.supports_automatic_install(forge_version):
        raise RuntimeError(
            f"Forge build {forge_version} does not support automatic installation."
        )
    mll.forge.install_forge_version(forge_version, minecraft_directory, callback=callback)


def _make_progress_callback(status_cb=None, progress_cb=None, max_cb=None) -> dict:
    callback = {}
    if status_cb:
        callback["setStatus"] = status_cb
    if progress_cb:
        callback["setProgress"] = progress_cb
    if max_cb:
        callback["setMax"] = max_cb
    return callback


def build_progress_callback(status_cb=None, progress_cb=None, max_cb=None) -> dict:
    return _make_progress_callback(status_cb, progress_cb, max_cb)


def launch_game(
    version_id: str,
    minecraft_directory: str,
    account: dict,
    java_path: str,
    ram_min_mb: int,
    ram_max_mb: int,
    extra_jvm_args: str = "",
    width: int = 1280,
    height: int = 720,
) -> subprocess.Popen:
    jvm_args = [f"-Xms{ram_min_mb}M", f"-Xmx{ram_max_mb}M"]
    if extra_jvm_args.strip():
        jvm_args.extend(extra_jvm_args.split())

    options: mll.types.MinecraftOptions = {
        "username": account["name"],
        "uuid": account["id"],
        "token": account["access_token"],
        "gameDirectory": minecraft_directory,
        "jvmArguments": jvm_args,
        "launcherName": "PyMC Launcher",
        "launcherVersion": "1.0.0",
        "customResolution": True,
        "resolutionWidth": str(width),
        "resolutionHeight": str(height),
    }
    if java_path:
        options["executablePath"] = java_path

    command = mll.command.get_minecraft_command(version_id, minecraft_directory, options)
    return subprocess.Popen(command, cwd=minecraft_directory)


def ensure_java(version_id: str, minecraft_directory: str, configured_java_path: str,
                 callback: dict | None = None) -> str:
    """Use a user-configured Java path if set, otherwise auto-resolve/download one."""
    if configured_java_path:
        return configured_java_path
    return java_manager.ensure_java_for_version(version_id, minecraft_directory, callback)

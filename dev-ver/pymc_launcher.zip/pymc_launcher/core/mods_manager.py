"""
Simple mod management for the mods/ folder inside a Minecraft instance.
Works with any loader that reads a standard 'mods' directory (Forge, Fabric,
Quilt, NeoForge). Disabling a mod just renames it with a '.disabled' suffix,
so the loader ignores it without deleting anything.
"""

import os
import shutil

DISABLED_SUFFIX = ".disabled"


def mods_directory(minecraft_directory: str) -> str:
    path = os.path.join(minecraft_directory, "mods")
    os.makedirs(path, exist_ok=True)
    return path


def list_mods(minecraft_directory: str) -> list[dict]:
    folder = mods_directory(minecraft_directory)
    mods = []
    for name in sorted(os.listdir(folder)):
        full_path = os.path.join(folder, name)
        if not os.path.isfile(full_path):
            continue
        enabled = not name.endswith(DISABLED_SUFFIX)
        display_name = name[: -len(DISABLED_SUFFIX)] if not enabled else name
        if not display_name.lower().endswith(".jar"):
            continue
        mods.append({
            "filename": name,
            "display_name": display_name,
            "enabled": enabled,
            "path": full_path,
            "size_kb": round(os.path.getsize(full_path) / 1024, 1),
        })
    return mods


def add_mod(minecraft_directory: str, source_jar_path: str) -> str:
    folder = mods_directory(minecraft_directory)
    filename = os.path.basename(source_jar_path)
    destination = os.path.join(folder, filename)
    shutil.copy2(source_jar_path, destination)
    return destination


def set_mod_enabled(minecraft_directory: str, filename: str, enabled: bool) -> str:
    folder = mods_directory(minecraft_directory)
    current_path = os.path.join(folder, filename)

    if enabled and filename.endswith(DISABLED_SUFFIX):
        new_name = filename[: -len(DISABLED_SUFFIX)]
    elif not enabled and not filename.endswith(DISABLED_SUFFIX):
        new_name = filename + DISABLED_SUFFIX
    else:
        return current_path  # already in the desired state

    new_path = os.path.join(folder, new_name)
    os.rename(current_path, new_path)
    return new_path


def remove_mod(minecraft_directory: str, filename: str) -> None:
    folder = mods_directory(minecraft_directory)
    path = os.path.join(folder, filename)
    if os.path.isfile(path):
        os.remove(path)

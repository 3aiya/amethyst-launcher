"""
Skin management using Mojang's official Minecraft Services API.
Only works for Microsoft-authenticated accounts (offline accounts have no
real profile to change).
"""

import requests

PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"
SKIN_URL = f"{PROFILE_URL}/skins"


class SkinError(Exception):
    pass


def _auth_headers(access_token: str) -> dict:
    return {"Authorization": f"Bearer {access_token}"}


def get_profile(access_token: str) -> dict:
    response = requests.get(PROFILE_URL, headers=_auth_headers(access_token), timeout=15)
    if response.status_code != 200:
        raise SkinError(f"Could not load profile ({response.status_code}).")
    return response.json()


def set_skin_from_url(access_token: str, image_url: str, variant: str = "classic") -> None:
    """variant is 'classic' (Steve model) or 'slim' (Alex model)."""
    payload = {"variant": variant, "url": image_url}
    response = requests.post(
        SKIN_URL, headers=_auth_headers(access_token), json=payload, timeout=20
    )
    if response.status_code not in (200, 204):
        raise SkinError(f"Skin upload failed: {response.status_code} {response.text[:200]}")


def set_skin_from_file(access_token: str, file_path: str, variant: str = "classic") -> None:
    with open(file_path, "rb") as f:
        files = {"file": ("skin.png", f, "image/png")}
        data = {"variant": variant}
        response = requests.post(
            SKIN_URL, headers=_auth_headers(access_token), data=data, files=files, timeout=30
        )
    if response.status_code not in (200, 204):
        raise SkinError(f"Skin upload failed: {response.status_code} {response.text[:200]}")


def reset_skin(access_token: str) -> None:
    response = requests.delete(SKIN_URL + "/active", headers=_auth_headers(access_token), timeout=15)
    if response.status_code not in (200, 204):
        raise SkinError(f"Could not reset skin: {response.status_code} {response.text[:200]}")

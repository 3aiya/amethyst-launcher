import os

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QCheckBox, QProgressBar, QStackedWidget, QListWidget,
    QListWidgetItem, QFileDialog, QMessageBox, QLineEdit, QSpinBox,
    QGroupBox, QFormLayout, QRadioButton, QButtonGroup, QFrame, QSizePolicy,
)

from core import config as config_module
from core import mods_manager, skin_manager, auth
from ui.login_dialog import LoginDialog
from ui.workers import InstallWorker, LaunchWorker, VersionListWorker

NAV_ITEMS = [
    ("Play", "\u25B6"),
    ("Mods", "\U0001F9E9"),
    ("Skins", "\U0001F3A8"),
    ("Settings", "\u2699"),
]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyMC Launcher")
        self.resize(960, 620)

        self.config = config_module.load_config()
        self.available_versions: list[dict] = []
        self.install_worker = None
        self.launch_worker = None
        self.version_worker = None
        self.nav_buttons: list[QPushButton] = []

        self._build_ui()
        self._load_account_from_config()
        self.refresh_versions()
        self.refresh_mods()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())

        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_play_tab())
        self.stack.addWidget(self._build_mods_tab())
        self.stack.addWidget(self._build_skins_tab())
        self.stack.addWidget(self._build_settings_tab())
        root.addWidget(self.stack, stretch=1)

    def _build_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(230)

        v = QVBoxLayout(sidebar)
        v.setContentsMargins(14, 20, 14, 16)
        v.setSpacing(4)

        logo = QLabel("PyMC <span style=\"color:#FF00FF;\">Launcher</span>")
        logo.setObjectName("logo")
        logo.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(logo)
        v.addSpacing(24)

        for index, (label, icon) in enumerate(NAV_ITEMS):
            btn = QPushButton(f"  {icon}   {label}")
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setMinimumHeight(40)
            btn.clicked.connect(lambda _checked, i=index: self._switch_page(i))
            v.addWidget(btn)
            self.nav_buttons.append(btn)

        self.nav_buttons[0].setChecked(True)

        v.addStretch()

        divider = QFrame()
        divider.setObjectName("sidebarDivider")
        v.addWidget(divider)
        v.addSpacing(10)

        account_card = QWidget()
        account_card.setObjectName("accountCard")
        ac_layout = QVBoxLayout(account_card)
        ac_layout.setContentsMargins(12, 10, 12, 10)
        ac_layout.setSpacing(2)

        self.account_label = QLabel("Not signed in")
        self.account_label.setObjectName("accountName")
        self.account_label.setWordWrap(True)
        ac_layout.addWidget(self.account_label)

        self.account_mode_label = QLabel("")
        self.account_mode_label.setObjectName("accountMode")
        ac_layout.addWidget(self.account_mode_label)

        signin_btn = QPushButton("Switch account")
        signin_btn.clicked.connect(self._open_login_dialog)
        ac_layout.addWidget(signin_btn)

        v.addWidget(account_card)
        return sidebar

    def _switch_page(self, index: int):
        self.stack.setCurrentIndex(index)
        for i, btn in enumerate(self.nav_buttons):
            btn.setChecked(i == index)

    def _page_header(self, title: str, subtitle: str) -> QVBoxLayout:
        header = QVBoxLayout()
        header.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName("pageTitle")
        header.addWidget(title_label)
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("pageSubtitle")
        header.addWidget(subtitle_label)
        return header

    def _build_play_tab(self) -> QWidget:
        tab = QWidget()
        tab.setObjectName("page")
        v = QVBoxLayout(tab)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(16)

        v.addLayout(self._page_header("Play", "Choose a version and mod loader, then launch."))

        card = QWidget()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 18, 18, 18)
        card_layout.setSpacing(12)

        loader_row = QHBoxLayout()
        loader_row.addWidget(QLabel("Loader"))
        self.loader_combo = QComboBox()
        self.loader_combo.addItems(["Vanilla", "Fabric", "Forge"])
        loader_row.addWidget(self.loader_combo, stretch=1)
        card_layout.addLayout(loader_row)

        version_row = QHBoxLayout()
        version_row.addWidget(QLabel("Version"))
        self.version_combo = QComboBox()
        version_row.addWidget(self.version_combo, stretch=1)
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh_versions)
        version_row.addWidget(refresh_btn)
        card_layout.addLayout(version_row)

        filter_row = QHBoxLayout()
        self.snapshots_check = QCheckBox("Show snapshots")
        self.snapshots_check.setChecked(self.config["show_snapshots"])
        self.snapshots_check.stateChanged.connect(self._on_filters_changed)
        self.old_versions_check = QCheckBox("Show old alpha/beta")
        self.old_versions_check.setChecked(self.config["show_old_versions"])
        self.old_versions_check.stateChanged.connect(self._on_filters_changed)
        filter_row.addWidget(self.snapshots_check)
        filter_row.addWidget(self.old_versions_check)
        filter_row.addStretch()
        card_layout.addLayout(filter_row)

        v.addWidget(card)
        v.addStretch()

        self.status_label = QLabel("")
        self.status_label.setObjectName("mutedLabel")
        v.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        v.addWidget(self.progress_bar)

        self.play_btn = QPushButton("Install & Play")
        self.play_btn.setObjectName("primaryButton")
        self.play_btn.setMinimumHeight(46)
        self.play_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play_btn.clicked.connect(self._on_play_clicked)
        v.addWidget(self.play_btn)

        return tab

    def _build_mods_tab(self) -> QWidget:
        tab = QWidget()
        tab.setObjectName("page")
        v = QVBoxLayout(tab)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(16)

        v.addLayout(self._page_header(
            "Mods",
            "Applies to the current game directory - use Fabric or Forge on the Play tab for mods to load.",
        ))

        self.mods_list = QListWidget()
        v.addWidget(self.mods_list, stretch=1)

        row = QHBoxLayout()
        add_btn = QPushButton("Add mod (.jar)")
        add_btn.clicked.connect(self._on_add_mod)
        remove_btn = QPushButton("Remove selected")
        remove_btn.clicked.connect(self._on_remove_mod)
        toggle_btn = QPushButton("Enable/disable selected")
        toggle_btn.clicked.connect(self._on_toggle_mod)
        open_folder_btn = QPushButton("Open mods folder")
        open_folder_btn.clicked.connect(self._on_open_mods_folder)
        row.addWidget(add_btn)
        row.addWidget(remove_btn)
        row.addWidget(toggle_btn)
        row.addWidget(open_folder_btn)
        v.addLayout(row)

        return tab

    def _build_skins_tab(self) -> QWidget:
        tab = QWidget()
        tab.setObjectName("page")
        v = QVBoxLayout(tab)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(16)

        v.addLayout(self._page_header(
            "Skins",
            "Requires a signed-in Microsoft account - offline accounts have no real profile to update.",
        ))

        card = QWidget()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 18, 18, 18)
        card_layout.setSpacing(12)

        variant_group = QGroupBox("Model")
        variant_row = QHBoxLayout(variant_group)
        self.classic_radio = QRadioButton("Classic (Steve)")
        self.slim_radio = QRadioButton("Slim (Alex)")
        self.classic_radio.setChecked(True)
        self.variant_buttons = QButtonGroup(self)
        self.variant_buttons.addButton(self.classic_radio)
        self.variant_buttons.addButton(self.slim_radio)
        variant_row.addWidget(self.classic_radio)
        variant_row.addWidget(self.slim_radio)
        card_layout.addWidget(variant_group)

        upload_btn = QPushButton("Upload skin (.png)...")
        upload_btn.clicked.connect(self._on_upload_skin)
        card_layout.addWidget(upload_btn)

        reset_btn = QPushButton("Reset to default skin")
        reset_btn.clicked.connect(self._on_reset_skin)
        card_layout.addWidget(reset_btn)

        self.skin_status_label = QLabel("")
        self.skin_status_label.setObjectName("mutedLabel")
        self.skin_status_label.setWordWrap(True)
        card_layout.addWidget(self.skin_status_label)

        v.addWidget(card)
        v.addStretch()
        return tab

    def _build_settings_tab(self) -> QWidget:
        tab = QWidget()
        tab.setObjectName("page")
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(28, 24, 28, 24)
        outer.setSpacing(16)

        outer.addLayout(self._page_header("Settings", "Game directory, memory, and Java options."))

        card = QWidget()
        card.setObjectName("card")
        form = QFormLayout(card)
        form.setContentsMargins(18, 18, 18, 18)
        form.setSpacing(12)

        dir_row = QHBoxLayout()
        self.game_dir_input = QLineEdit(self.config["game_directory"])
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._on_browse_game_dir)
        dir_row.addWidget(self.game_dir_input)
        dir_row.addWidget(browse_btn)
        form.addRow("Game directory:", dir_row)

        self.ram_min_spin = QSpinBox()
        self.ram_min_spin.setRange(512, 65536)
        self.ram_min_spin.setSingleStep(256)
        self.ram_min_spin.setValue(self.config["ram_min_mb"])
        form.addRow("Min RAM (MB):", self.ram_min_spin)

        self.ram_max_spin = QSpinBox()
        self.ram_max_spin.setRange(512, 65536)
        self.ram_max_spin.setSingleStep(256)
        self.ram_max_spin.setValue(self.config["ram_max_mb"])
        form.addRow("Max RAM (MB):", self.ram_max_spin)

        self.jvm_args_input = QLineEdit(self.config["jvm_args"])
        self.jvm_args_input.setPlaceholderText("Extra JVM arguments (optional)")
        form.addRow("JVM arguments:", self.jvm_args_input)

        java_row = QHBoxLayout()
        self.java_path_input = QLineEdit(self.config["java_path"])
        self.java_path_input.setPlaceholderText("Leave empty to auto-detect / auto-download")
        java_browse_btn = QPushButton("Browse...")
        java_browse_btn.clicked.connect(self._on_browse_java)
        java_row.addWidget(self.java_path_input)
        java_row.addWidget(java_browse_btn)
        form.addRow("Java executable:", java_row)

        save_btn = QPushButton("Save settings")
        save_btn.setObjectName("primaryButton")
        save_btn.clicked.connect(self._on_save_settings)
        form.addRow(save_btn)

        outer.addWidget(card)
        outer.addStretch()
        return tab

    # ------------------------------------------------------------------
    # Account handling
    # ------------------------------------------------------------------
    def _load_account_from_config(self):
        if self.config["auth_mode"] == "microsoft" and self.config.get("ms_account"):
            account = self.config["ms_account"]
            self.account_label.setText(account["name"])
            self.account_mode_label.setText("Microsoft account")
        else:
            name = self.config.get("offline_username", "Player")
            self.account_label.setText(name)
            self.account_mode_label.setText("Offline mode")

    def _current_account(self) -> dict:
        if self.config["auth_mode"] == "microsoft" and self.config.get("ms_account"):
            return self.config["ms_account"]
        return auth.offline_login(self.config.get("offline_username", "Player"))

    def _open_login_dialog(self):
        dialog = LoginDialog(self, existing_username=self.config.get("offline_username", "Player"))
        if dialog.exec():
            account = dialog.account
            if account["auth_mode"] == "microsoft":
                self.config["auth_mode"] = "microsoft"
                self.config["ms_account"] = account
            else:
                self.config["auth_mode"] = "offline"
                self.config["offline_username"] = account["name"]
            config_module.save_config(self.config)
            self._load_account_from_config()

    # ------------------------------------------------------------------
    # Versions
    # ------------------------------------------------------------------
    def _on_filters_changed(self):
        self.config["show_snapshots"] = self.snapshots_check.isChecked()
        self.config["show_old_versions"] = self.old_versions_check.isChecked()
        config_module.save_config(self.config)
        self.refresh_versions()

    def refresh_versions(self):
        self.status_label.setText("Loading version list...")
        self.version_worker = VersionListWorker(
            self.snapshots_check.isChecked() if hasattr(self, "snapshots_check") else False,
            self.old_versions_check.isChecked() if hasattr(self, "old_versions_check") else False,
        )
        self.version_worker.loaded.connect(self._on_versions_loaded)
        self.version_worker.failed.connect(lambda msg: self.status_label.setText(f"Error: {msg}"))
        self.version_worker.start()

    def _installed_version_ids(self) -> set:
        import minecraft_launcher_lib as mll
        game_dir = config_module.ensure_game_directory(self.config)
        try:
            return {v["id"] for v in mll.utils.get_installed_versions(game_dir)}
        except Exception:  # noqa: BLE001
            return set()

    def _on_versions_loaded(self, versions: list):
        self.available_versions = versions
        installed = self._installed_version_ids()

        self.version_combo.clear()
        for v in versions:
            label = v["id"] + ("  [installed]" if v["id"] in installed else "")
            self.version_combo.addItem(label, v["id"])

        preferred = self.config.get("selected_version")
        if preferred:
            index = self.version_combo.findData(preferred)
            if index >= 0:
                self.version_combo.setCurrentIndex(index)

        self.status_label.setText(f"{len(versions)} versions available.")

    # ------------------------------------------------------------------
    # Play / install
    # ------------------------------------------------------------------
    def _on_play_clicked(self):
        version_id = self.version_combo.currentData()
        if not version_id:
            QMessageBox.warning(self, "No version selected", "Pick a Minecraft version first.")
            return

        loader = self.loader_combo.currentText().lower()
        self.config["selected_version"] = version_id
        self.config["selected_loader"] = loader
        config_module.save_config(self.config)

        game_dir = config_module.ensure_game_directory(self.config)

        self.play_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        self.install_worker = InstallWorker(version_id, game_dir, loader)
        self.install_worker.status.connect(self.status_label.setText)
        self.install_worker.progress.connect(self.progress_bar.setValue)
        self.install_worker.maximum.connect(self.progress_bar.setMaximum)
        self.install_worker.finished_ok.connect(self._on_install_done)
        self.install_worker.failed.connect(self._on_install_failed)
        self.install_worker.start()

    def _on_install_done(self):
        self.progress_bar.setVisible(False)
        version_id = self.version_combo.currentData()
        game_dir = config_module.ensure_game_directory(self.config)
        account = self._current_account()

        self.status_label.setText("Launching...")
        self.launch_worker = LaunchWorker(
            version_id,
            game_dir,
            account,
            self.config.get("java_path", ""),
            self.config.get("ram_min_mb", 1024),
            self.config.get("ram_max_mb", 2048),
            self.config.get("jvm_args", ""),
            self.config.get("resolution_width", 1280),
            self.config.get("resolution_height", 720),
        )
        self.launch_worker.status.connect(self.status_label.setText)
        self.launch_worker.launched.connect(self._on_launched)
        self.launch_worker.failed.connect(self._on_install_failed)
        self.launch_worker.start()

    def _on_launched(self):
        self.status_label.setText("Minecraft launched!")
        self.play_btn.setEnabled(True)

    def _on_install_failed(self, message: str):
        self.progress_bar.setVisible(False)
        self.play_btn.setEnabled(True)
        self.status_label.setText("Error - see popup.")
        QMessageBox.critical(self, "Something went wrong", message)

    # ------------------------------------------------------------------
    # Mods
    # ------------------------------------------------------------------
    def refresh_mods(self):
        self.mods_list.clear()
        game_dir = config_module.ensure_game_directory(self.config)
        for mod in mods_manager.list_mods(game_dir):
            label = f"{mod['display_name']}  ({mod['size_kb']} KB)"
            if not mod["enabled"]:
                label += "  [disabled]"
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, mod["filename"])
            self.mods_list.addItem(item)

    def _on_add_mod(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Select mod jar files", "", "Jar files (*.jar)")
        if not paths:
            return
        game_dir = config_module.ensure_game_directory(self.config)
        for path in paths:
            mods_manager.add_mod(game_dir, path)
        self.refresh_mods()

    def _selected_mod_filename(self) -> str | None:
        item = self.mods_list.currentItem()
        if not item:
            QMessageBox.information(self, "No mod selected", "Select a mod first.")
            return None
        return item.data(Qt.ItemDataRole.UserRole)

    def _on_remove_mod(self):
        filename = self._selected_mod_filename()
        if not filename:
            return
        game_dir = config_module.ensure_game_directory(self.config)
        mods_manager.remove_mod(game_dir, filename)
        self.refresh_mods()

    def _on_toggle_mod(self):
        filename = self._selected_mod_filename()
        if not filename:
            return
        game_dir = config_module.ensure_game_directory(self.config)
        currently_enabled = not filename.endswith(mods_manager.DISABLED_SUFFIX)
        mods_manager.set_mod_enabled(game_dir, filename, not currently_enabled)
        self.refresh_mods()

    def _on_open_mods_folder(self):
        import subprocess
        import sys

        game_dir = config_module.ensure_game_directory(self.config)
        folder = mods_manager.mods_directory(game_dir)
        if sys.platform == "win32":
            os.startfile(folder)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])

    # ------------------------------------------------------------------
    # Skins
    # ------------------------------------------------------------------
    def _require_microsoft_account(self) -> dict | None:
        if self.config["auth_mode"] != "microsoft" or not self.config.get("ms_account"):
            QMessageBox.warning(
                self, "Microsoft account required",
                "Sign in with a Microsoft account first (Switch account, bottom of sidebar)."
            )
            return None
        return self.config["ms_account"]

    def _on_upload_skin(self):
        account = self._require_microsoft_account()
        if not account:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Select skin PNG", "", "PNG images (*.png)")
        if not path:
            return
        variant = "classic" if self.classic_radio.isChecked() else "slim"
        try:
            skin_manager.set_skin_from_file(account["access_token"], path, variant)
            self.skin_status_label.setText("Skin uploaded successfully.")
        except skin_manager.SkinError as exc:
            self.skin_status_label.setText("")
            QMessageBox.critical(self, "Upload failed", str(exc))

    def _on_reset_skin(self):
        account = self._require_microsoft_account()
        if not account:
            return
        try:
            skin_manager.reset_skin(account["access_token"])
            self.skin_status_label.setText("Skin reset to default.")
        except skin_manager.SkinError as exc:
            self.skin_status_label.setText("")
            QMessageBox.critical(self, "Reset failed", str(exc))

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------
    def _on_browse_game_dir(self):
        path = QFileDialog.getExistingDirectory(self, "Choose game directory", self.game_dir_input.text())
        if path:
            self.game_dir_input.setText(path)

    def _on_browse_java(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose java executable")
        if path:
            self.java_path_input.setText(path)

    def _on_save_settings(self):
        self.config["game_directory"] = self.game_dir_input.text().strip() or self.config["game_directory"]
        self.config["ram_min_mb"] = self.ram_min_spin.value()
        self.config["ram_max_mb"] = max(self.ram_max_spin.value(), self.ram_min_spin.value())
        self.config["jvm_args"] = self.jvm_args_input.text().strip()
        self.config["java_path"] = self.java_path_input.text().strip()
        config_module.save_config(self.config)
        config_module.ensure_game_directory(self.config)
        QMessageBox.information(self, "Saved", "Settings saved.")
        self.refresh_versions()
        self.refresh_mods()

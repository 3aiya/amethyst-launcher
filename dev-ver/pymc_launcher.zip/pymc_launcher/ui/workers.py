"""
Background QThread workers. All slow/network operations (installing
versions, downloading Java, logging in, launching) run here so the GUI
never freezes.
"""

from PyQt6.QtCore import QThread, pyqtSignal

from core import auth, launcher


class InstallWorker(QThread):
    status = pyqtSignal(str)
    progress = pyqtSignal(int)
    maximum = pyqtSignal(int)
    finished_ok = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, version_id: str, minecraft_directory: str, loader: str = "vanilla"):
        super().__init__()
        self.version_id = version_id
        self.minecraft_directory = minecraft_directory
        self.loader = loader

    def _callback(self) -> dict:
        return launcher.build_progress_callback(
            status_cb=self.status.emit,
            progress_cb=self.progress.emit,
            max_cb=self.maximum.emit,
        )

    def run(self):
        try:
            callback = self._callback()

            self.status.emit(f"Installing Minecraft {self.version_id}...")
            launcher.install_vanilla(self.version_id, self.minecraft_directory, callback)

            if self.loader == "fabric":
                self.status.emit("Installing Fabric loader...")
                launcher.install_fabric_loader(self.version_id, self.minecraft_directory, callback)
            elif self.loader == "forge":
                self.status.emit("Looking up matching Forge build...")
                forge_version = launcher.find_forge_version(self.version_id)
                if not forge_version:
                    raise RuntimeError(f"No Forge build found for {self.version_id}.")
                self.status.emit(f"Installing Forge {forge_version}...")
                launcher.install_forge_loader(self.minecraft_directory, callback, forge_version)

            self.status.emit("Checking Java runtime...")
            launcher.ensure_java(self.version_id, self.minecraft_directory, "", callback)

            self.status.emit("Done.")
            self.finished_ok.emit()
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class LaunchWorker(QThread):
    status = pyqtSignal(str)
    progress = pyqtSignal(int)
    maximum = pyqtSignal(int)
    launched = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, version_id, minecraft_directory, account, java_path,
                 ram_min_mb, ram_max_mb, jvm_args, width, height):
        super().__init__()
        self.version_id = version_id
        self.minecraft_directory = minecraft_directory
        self.account = account
        self.java_path = java_path
        self.ram_min_mb = ram_min_mb
        self.ram_max_mb = ram_max_mb
        self.jvm_args = jvm_args
        self.width = width
        self.height = height

    def run(self):
        try:
            callback = launcher.build_progress_callback(
                status_cb=self.status.emit,
                progress_cb=self.progress.emit,
                max_cb=self.maximum.emit,
            )
            self.status.emit("Preparing Java...")
            java_path = launcher.ensure_java(
                self.version_id, self.minecraft_directory, self.java_path, callback
            )

            self.status.emit("Launching Minecraft...")
            launcher.launch_game(
                self.version_id,
                self.minecraft_directory,
                self.account,
                java_path,
                self.ram_min_mb,
                self.ram_max_mb,
                self.jvm_args,
                self.width,
                self.height,
            )
            self.launched.emit()
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class VersionListWorker(QThread):
    loaded = pyqtSignal(list)
    failed = pyqtSignal(str)

    def __init__(self, show_snapshots: bool, show_old_versions: bool):
        super().__init__()
        self.show_snapshots = show_snapshots
        self.show_old_versions = show_old_versions

    def run(self):
        try:
            versions = launcher.get_available_versions(self.show_snapshots, self.show_old_versions)
            self.loaded.emit(versions)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class MicrosoftLoginWorker(QThread):
    success = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, redirect_url: str):
        super().__init__()
        self.redirect_url = redirect_url

    def run(self):
        try:
            account = auth.complete_microsoft_login(self.redirect_url)
            self.success.emit(account)
        except auth.AuthError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))

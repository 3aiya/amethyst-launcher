"""
Dark theme in the spirit of Modrinth's UI: a fixed left sidebar for
navigation, rounded cards, and a single accent color used sparingly for
selection states, primary actions, and progress.
"""

ACCENT = "#FF00FF"
ACCENT_HOVER = "#E000E0"
ACCENT_PRESSED = "#C400C4"
ACCENT_SOFT = "rgba(255, 0, 255, 0.16)"
ACCENT_SOFT_HOVER = "rgba(255, 0, 255, 0.24)"

BG = "#121214"
BG_SIDEBAR = "#0d0d0f"
BG_ELEVATED = "#1a1a1e"
BG_CARD = "#1e1e23"
BG_CARD_HOVER = "#26262c"
BORDER = "#2a2a30"
BORDER_LIGHT = "#34343b"

TEXT = "#EDEDF0"
TEXT_MUTED = "#9a9aa5"
TEXT_FAINT = "#6b6b74"

RADIUS = "10px"
RADIUS_SM = "6px"

THEME_QSS = f"""
* {{
    outline: none;
}}

QMainWindow, QWidget {{
    background-color: {BG};
    color: {TEXT};
    font-family: "Segoe UI", "Inter", "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
}}

/* ---------- Sidebar ---------- */
QWidget#sidebar {{
    background-color: {BG_SIDEBAR};
    border-right: 1px solid {BORDER};
}}

QLabel#logo {{
    color: {TEXT};
    font-size: 19px;
    font-weight: 700;
    padding: 4px 8px;
}}

QLabel#logoAccent {{
    color: {ACCENT};
}}

QPushButton#navButton {{
    text-align: left;
    padding: 10px 12px;
    border-radius: {RADIUS_SM};
    border: none;
    background-color: transparent;
    color: {TEXT_MUTED};
    font-size: 14px;
    font-weight: 500;
}}

QPushButton#navButton:hover {{
    background-color: {BG_CARD};
    color: {TEXT};
}}

QPushButton#navButton:checked {{
    background-color: {ACCENT_SOFT};
    color: {ACCENT};
    font-weight: 600;
}}

QFrame#sidebarDivider {{
    background-color: {BORDER};
    max-height: 1px;
    min-height: 1px;
}}

QWidget#accountCard {{
    background-color: {BG_CARD};
    border: 1px solid {BORDER};
    border-radius: {RADIUS};
}}

QLabel#accountName {{
    color: {TEXT};
    font-weight: 600;
    font-size: 13px;
}}

QLabel#accountMode {{
    color: {TEXT_MUTED};
    font-size: 11px;
}}

/* ---------- Page headers ---------- */
QLabel#pageTitle {{
    font-size: 22px;
    font-weight: 700;
    color: {TEXT};
}}

QLabel#pageSubtitle {{
    color: {TEXT_MUTED};
    font-size: 13px;
}}

QWidget#page {{
    background-color: {BG};
}}

/* ---------- Cards ---------- */
QWidget#card {{
    background-color: {BG_CARD};
    border: 1px solid {BORDER};
    border-radius: {RADIUS};
}}

/* ---------- Buttons ---------- */
QPushButton {{
    background-color: {BG_CARD};
    color: {TEXT};
    border: 1px solid {BORDER_LIGHT};
    border-radius: {RADIUS_SM};
    padding: 8px 14px;
    font-weight: 500;
}}

QPushButton:hover {{
    background-color: {BG_CARD_HOVER};
    border-color: {ACCENT};
}}

QPushButton:pressed {{
    background-color: {BORDER};
}}

QPushButton:disabled {{
    color: {TEXT_FAINT};
    border-color: {BORDER};
}}

QPushButton#primaryButton {{
    background-color: {ACCENT};
    color: #1a001a;
    border: none;
    font-weight: 700;
    font-size: 14px;
    padding: 12px 16px;
    border-radius: {RADIUS};
}}

QPushButton#primaryButton:hover {{
    background-color: {ACCENT_HOVER};
}}

QPushButton#primaryButton:pressed {{
    background-color: {ACCENT_PRESSED};
}}

QPushButton#primaryButton:disabled {{
    background-color: {BORDER_LIGHT};
    color: {TEXT_FAINT};
}}

/* ---------- Inputs ---------- */
QLineEdit, QTextEdit, QSpinBox, QComboBox {{
    background-color: {BG_ELEVATED};
    border: 1px solid {BORDER_LIGHT};
    border-radius: {RADIUS_SM};
    padding: 7px 10px;
    color: {TEXT};
    selection-background-color: {ACCENT};
}}

QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {{
    border: 1px solid {ACCENT};
}}

QComboBox::drop-down {{
    border: none;
    width: 24px;
}}

QComboBox QAbstractItemView {{
    background-color: {BG_ELEVATED};
    border: 1px solid {BORDER_LIGHT};
    selection-background-color: {ACCENT_SOFT};
    selection-color: {ACCENT};
    color: {TEXT};
    outline: none;
    padding: 4px;
}}

/* ---------- Lists ---------- */
QListWidget {{
    background-color: {BG_ELEVATED};
    border: 1px solid {BORDER};
    border-radius: {RADIUS};
    padding: 4px;
}}

QListWidget::item {{
    padding: 9px 10px;
    border-radius: {RADIUS_SM};
    margin: 2px 0;
    color: {TEXT};
}}

QListWidget::item:hover {{
    background-color: {BG_CARD_HOVER};
}}

QListWidget::item:selected {{
    background-color: {ACCENT_SOFT};
    color: {ACCENT};
}}

/* ---------- Progress bar ---------- */
QProgressBar {{
    background-color: {BG_ELEVATED};
    border: 1px solid {BORDER};
    border-radius: {RADIUS_SM};
    text-align: center;
    color: {TEXT};
    height: 18px;
}}

QProgressBar::chunk {{
    background-color: {ACCENT};
    border-radius: {RADIUS_SM};
}}

/* ---------- Checkboxes / Radio ---------- */
QCheckBox, QRadioButton {{
    color: {TEXT};
    spacing: 8px;
}}

QCheckBox::indicator, QRadioButton::indicator {{
    width: 16px;
    height: 16px;
    border: 1px solid {BORDER_LIGHT};
    background-color: {BG_ELEVATED};
}}

QCheckBox::indicator {{
    border-radius: 4px;
}}

QRadioButton::indicator {{
    border-radius: 8px;
}}

QCheckBox::indicator:checked, QRadioButton::indicator:checked {{
    background-color: {ACCENT};
    border-color: {ACCENT};
}}

/* ---------- Group boxes ---------- */
QGroupBox {{
    border: 1px solid {BORDER};
    border-radius: {RADIUS};
    margin-top: 10px;
    padding-top: 14px;
    color: {TEXT_MUTED};
    font-weight: 600;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 6px;
    color: {TEXT_MUTED};
}}

/* ---------- Scrollbars ---------- */
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background: {BORDER_LIGHT};
    border-radius: 5px;
    min-height: 24px;
}}

QScrollBar::handle:vertical:hover {{
    background: {ACCENT};
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}

/* ---------- Labels ---------- */
QLabel {{
    color: {TEXT};
}}

QLabel#mutedLabel {{
    color: {TEXT_MUTED};
    font-size: 12px;
}}

/* ---------- Tooltips ---------- */
QToolTip {{
    background-color: {BG_ELEVATED};
    color: {TEXT};
    border: 1px solid {BORDER_LIGHT};
    padding: 4px 8px;
    border-radius: {RADIUS_SM};
}}
"""

import webbrowser

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTabWidget, QWidget, QMessageBox, QTextEdit,
)

from core import auth
from ui.workers import MicrosoftLoginWorker


class LoginDialog(QDialog):
    def __init__(self, parent=None, existing_username: str = "Player"):
        super().__init__(parent)
        self.setWindowTitle("Sign in")
        self.setMinimumWidth(420)
        self.account: dict | None = None
        self._worker: MicrosoftLoginWorker | None = None

        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.tabs.addTab(self._build_offline_tab(existing_username), "Offline")
        self.tabs.addTab(self._build_microsoft_tab(), "Microsoft account")

    # ---- Offline tab -----------------------------------------------
    def _build_offline_tab(self, existing_username: str) -> QWidget:
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.addWidget(QLabel(
            "Play without signing in. Works for singleplayer, LAN, and\n"
            "offline-mode servers with a legally owned copy of the game."
        ))

        self.username_input = QLineEdit(existing_username)
        self.username_input.setPlaceholderText("Username")
        v.addWidget(self.username_input)

        offline_btn = QPushButton("Continue offline")
        offline_btn.clicked.connect(self._on_offline_confirmed)
        v.addWidget(offline_btn)
        v.addStretch()
        return tab

    def _on_offline_confirmed(self):
        try:
            self.account = auth.offline_login(self.username_input.text())
            self.accept()
        except auth.AuthError as exc:
            QMessageBox.warning(self, "Invalid username", str(exc))

    # ---- Microsoft tab -----------------------------------------------
    def _build_microsoft_tab(self) -> QWidget:
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.addWidget(QLabel(
            "1. Click 'Open Microsoft login' and sign in with the account\n"
            "   that owns Minecraft.\n"
            "2. After signing in, the browser lands on a page that may look\n"
            "   blank or show an error - that's expected. Copy the FULL\n"
            "   address bar URL and paste it below."
        ))

        open_btn = QPushButton("Open Microsoft login")
        open_btn.clicked.connect(self._open_login_page)
        v.addWidget(open_btn)

        self.redirect_input = QTextEdit()
        self.redirect_input.setPlaceholderText("Paste the redirect URL here...")
        self.redirect_input.setFixedHeight(70)
        v.addWidget(self.redirect_input)

        row = QHBoxLayout()
        self.login_btn = QPushButton("Complete sign-in")
        self.login_btn.clicked.connect(self._complete_login)
        row.addWidget(self.login_btn)
        v.addLayout(row)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        v.addWidget(self.status_label)
        v.addStretch()
        return tab

    def _open_login_page(self):
        try:
            url = auth.get_microsoft_login_url()
        except auth.AuthError as exc:
            QMessageBox.warning(self, "Not configured", str(exc))
            return
        webbrowser.open(url)

    def _complete_login(self):
        redirect_url = self.redirect_input.toPlainText().strip()
        if not redirect_url:
            QMessageBox.warning(self, "Missing URL", "Paste the redirect URL first.")
            return

        self.login_btn.setEnabled(False)
        self.status_label.setText("Signing in...")

        self._worker = MicrosoftLoginWorker(redirect_url)
        self._worker.success.connect(self._on_login_success)
        self._worker.failed.connect(self._on_login_failed)
        self._worker.start()

    def _on_login_success(self, account: dict):
        self.account = account
        self.accept()

    def _on_login_failed(self, message: str):
        self.login_btn.setEnabled(True)
        self.status_label.setText("")
        QMessageBox.critical(self, "Login failed", message)

import { motion } from "framer-motion";
import { Play, Blocks, Palette, Settings as SettingsIcon } from "lucide-react";
import type { AmethystSettings } from "../types/global";

export type Page = "play" | "mods" | "skins" | "settings";

const NAV_ITEMS: { id: Page; label: string; icon: typeof Play }[] = [
  { id: "play", label: "Play", icon: Play },
  { id: "mods", label: "Mods", icon: Blocks },
  { id: "skins", label: "Skins", icon: Palette },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  settings: AmethystSettings | null;
  onSwitchAccount: () => void;
}

export default function Sidebar({ currentPage, onNavigate, settings, onSwitchAccount }: SidebarProps) {
  const accountName = settings?.account?.name ?? settings?.offlineUsername ?? "Player";
  const accountMode = settings?.authMode === "microsoft" ? "Microsoft account" : "Offline mode";

  return (
    <aside className="flex w-56 shrink-0 flex-col bg-bg-sidebar border-r border-border px-3 py-4">
      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? "text-accent" : "text-zinc-400 hover:text-zinc-100"
              }`}
            >
              {active && (
                <motion.span
                  layoutId="sidebar-active-pill"
                  className="absolute inset-0 rounded-lg bg-accent/15"
                  transition={{ type: "spring", stiffness: 380, damping: 32 }}
                />
              )}
              <Icon size={17} className="relative z-10" />
              <span className="relative z-10">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="flex-1" />

      <div className="rounded-xl border border-border bg-bg-card p-3">
        <p className="truncate text-sm font-semibold text-zinc-100">{accountName}</p>
        <p className="mb-2.5 text-xs text-zinc-500">{accountMode}</p>
        <button
          onClick={onSwitchAccount}
          className="w-full rounded-lg border border-border-light bg-bg-elevated py-1.5 text-xs font-medium text-zinc-200 hover:border-accent hover:text-accent transition-colors"
        >
          Switch account
        </button>
      </div>
    </aside>
  );
}

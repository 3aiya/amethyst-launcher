import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import {
  Search,
  Download,
  Loader2,
  Package,
  Newspaper,
  MessageCircle,
  Video,
} from "lucide-react";
import type { Profile, BrowseCategory, ModrinthSearchResult, NewsItem, SocialLinks } from "../types/global";

interface BrowsePageProps {
  profiles: Profile[];
  selectedProfileId: string | null;
  onSelectProfile: (id: string) => void;
}

const CATEGORIES: { id: BrowseCategory; label: string }[] = [
  { id: "modpack", label: "Modpacks" },
  { id: "mod", label: "Mods" },
  { id: "resourcepack", label: "Resource Packs" },
  { id: "datapack", label: "Data Packs" },
  { id: "shader", label: "Shaders" },
];

function timeAgo(dateStr: string): string {
  const date = new Date(dateStr);
  if (Number.isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export default function BrowsePage({ profiles, selectedProfileId, onSelectProfile }: BrowsePageProps) {
  const [category, setCategory] = useState<BrowseCategory>("mod");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<ModrinthSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [installingId, setInstallingId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState("");

  const [news, setNews] = useState<NewsItem[]>([]);
  const [socialLinks, setSocialLinks] = useState<SocialLinks | null>(null);

  const selectedProfile = profiles.find((p) => p.id === selectedProfileId) ?? null;

  const runSearch = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const gameVersion = selectedProfile?.version;
      const loader = selectedProfile?.loader === "amethyst" ? "fabric" : selectedProfile?.loader;
      const hits = await window.amethyst.browse.search(query, category, gameVersion, loader);
      setResults(hits);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [query, category, selectedProfile]);

  useEffect(() => {
    runSearch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  useEffect(() => {
    (async () => {
      setNews(await window.amethyst.news.get());
      setSocialLinks(await window.amethyst.news.getSocialLinks());
    })();
  }, []);

  useEffect(() => {
    const off = window.amethyst.browse.onInstallStatus(setStatusMessage);
    return off;
  }, []);

  async function handleInstall(result: ModrinthSearchResult) {
    setInstallingId(result.id);
    setStatusMessage("");
    try {
      const gameVersion = selectedProfile?.version;
      const loader = selectedProfile?.loader === "amethyst" ? "fabric" : selectedProfile?.loader;
      const versions = await window.amethyst.browse.getVersions(result.id, gameVersion, loader);
      const best = versions[0];
      if (!best) throw new Error("No compatible version found for this profile.");
      const file = best.files.find((f) => f.primary) ?? best.files[0];
      if (!file) throw new Error("This version has no downloadable file.");

      if (category === "modpack") {
        const created = await window.amethyst.browse.installModpack(file.url, result.title);
        setStatusMessage(`Installed as new instance: ${created.profileName}`);
      } else {
        if (!selectedProfileId) throw new Error("Pick an instance to install into first.");
        await window.amethyst.browse.installFile(selectedProfileId, category, file.url, file.filename);
        setStatusMessage(`Installed ${result.title}.`);
      }
    } catch (e) {
      setStatusMessage("");
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setInstallingId(null);
    }
  }

  return (
    <div className="flex h-full gap-4 p-6">
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        <div>
          <h1 className="text-2xl font-bold text-zinc-50">Browse</h1>
          <p className="text-sm text-zinc-500">
            Find mods, modpacks, resource packs, data packs, and shaders from Modrinth.
          </p>
        </div>

        {category !== "modpack" && (
          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">Installing into</label>
            <select
              value={selectedProfileId ?? ""}
              onChange={(e) => onSelectProfile(e.target.value)}
              className="w-full rounded-lg border border-border-light bg-bg-elevated px-3 py-2 text-sm text-zinc-100 outline-none focus:border-accent"
            >
              <option value="" disabled>
                Select an instance...
              </option>
              {profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.loader} {p.version})
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="flex items-center gap-2 rounded-full border border-border bg-bg-card p-1.5">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                category === c.id ? "bg-accent text-black" : "text-zinc-300 hover:bg-bg-card-hover"
              }`}
            >
              {c.label}
            </button>
          ))}
          <div className="ml-auto flex flex-1 items-center gap-2 rounded-full bg-bg-elevated px-3 py-2">
            <Search size={14} className="text-zinc-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && runSearch()}
              placeholder={`Search ${CATEGORIES.find((c) => c.id === category)?.label.toLowerCase()}...`}
              className="w-full bg-transparent text-sm text-zinc-100 outline-none placeholder:text-zinc-600"
            />
          </div>
        </div>

        {statusMessage && <p className="text-xs text-emerald-400">{statusMessage}</p>}
        {error && <p className="text-xs text-red-400">{error}</p>}

        <div className="flex-1 overflow-y-auto rounded-2xl border border-border bg-bg-elevated p-3">
          {loading && (
            <div className="flex h-full items-center justify-center text-zinc-500">
              <Loader2 size={20} className="animate-spin" />
            </div>
          )}

          {!loading && results.length === 0 && (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-zinc-600">
              <Package size={28} />
              <p className="text-sm">No results yet - try a search.</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            {results.map((result) => (
              <motion.div
                layout
                key={result.id}
                className="flex items-center gap-3 rounded-xl border border-border bg-bg-card p-3"
              >
                {result.iconUrl ? (
                  <img src={result.iconUrl} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />
                ) : (
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-bg-elevated text-accent">
                    <Package size={20} />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-zinc-100">{result.title}</p>
                  <p className="truncate text-xs text-zinc-500">{result.description}</p>
                  <p className="text-[11px] text-zinc-600">
                    by {result.author} · {result.downloads.toLocaleString()} downloads
                  </p>
                </div>
                <button
                  onClick={() => handleInstall(result)}
                  disabled={installingId === result.id || (category !== "modpack" && !selectedProfileId)}
                  className="flex shrink-0 items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-xs font-semibold text-black hover:bg-accent-hover disabled:opacity-40 transition-colors"
                >
                  {installingId === result.id ? (
                    <Loader2 size={13} className="animate-spin" />
                  ) : (
                    <Download size={13} />
                  )}
                  Install
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <NewsPanel news={news} socialLinks={socialLinks} />
    </div>
  );
}

function NewsPanel({ news, socialLinks }: { news: NewsItem[]; socialLinks: SocialLinks | null }) {
  return (
    <div className="flex w-72 shrink-0 flex-col rounded-2xl border border-border bg-bg-card">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Newspaper size={15} className="text-accent" />
        <span className="text-sm font-semibold text-zinc-100">News</span>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {news.length === 0 ? (
          <p className="p-4 text-center text-xs text-zinc-600">No news configured yet.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {news.map((item, i) => (
              <a
                key={i}
                href={item.url}
                onClick={(e) => !item.url && e.preventDefault()}
                className="block rounded-lg p-2.5 hover:bg-bg-card-hover transition-colors"
              >
                <p className="text-sm font-medium text-zinc-100">{item.title}</p>
                <p className="mt-0.5 line-clamp-2 text-xs text-zinc-500">{item.body}</p>
                <p className="mt-1 text-[10px] text-zinc-600">{timeAgo(item.date)}</p>
              </a>
            ))}
          </div>
        )}
      </div>

      {socialLinks && (
        <div className="flex items-center justify-center gap-3 border-t border-border px-4 py-3">
          {socialLinks.discord && (
            <a href={socialLinks.discord} className="text-zinc-500 hover:text-accent">
              <MessageCircle size={16} />
            </a>
          )}
          {socialLinks.youtube && (
            <a href={socialLinks.youtube} className="text-zinc-500 hover:text-accent">
              <Video size={16} />
            </a>
          )}
        </div>
      )}
    </div>
  );
}

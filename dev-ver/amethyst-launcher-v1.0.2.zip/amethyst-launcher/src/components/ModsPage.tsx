import { motion } from "framer-motion";
import { Plus, Trash2, ToggleLeft, ToggleRight, FolderTree } from "lucide-react";
import type { ModEntry, Profile } from "../types/global";

interface ModsPageProps {
  profiles: Profile[];
  selectedProfileId: string | null;
  onSelectProfile: (id: string) => void;
  mods: ModEntry[];
  selected: string | null;
  onSelect: (filename: string) => void;
  onAdd: () => void;
  onRemove: () => void;
  onToggle: () => void;
  onOpenFolder: () => void;
}

export default function ModsPage({
  profiles,
  selectedProfileId,
  onSelectProfile,
  mods,
  selected,
  onSelect,
  onAdd,
  onRemove,
  onToggle,
  onOpenFolder,
}: ModsPageProps) {
  return (
    <div className="flex h-full flex-col gap-4 p-6">
      <div>
        <h1 className="text-2xl font-bold text-zinc-50">Mods</h1>
        <p className="text-sm text-zinc-500">
          Mods live inside each instance separately - pick which one to manage below.
        </p>
      </div>

      <div>
        <label className="mb-1.5 block text-xs font-medium text-zinc-400">Instance</label>
        <select
          value={selectedProfileId ?? ""}
          onChange={(e) => onSelectProfile(e.target.value)}
          className="w-full rounded-lg border border-border-light bg-bg-elevated px-3 py-2 text-sm text-zinc-100 outline-none focus:border-accent"
        >
          <option value="" disabled>
            Select an instance...
          </option>
          {profiles.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} ({p.loader} {p.version})
            </option>
          ))}
        </select>
        {profiles.length === 0 && (
          <p className="mt-1.5 text-xs text-zinc-600">
            No instances yet - play something from the Play tab first.
          </p>
        )}
      </div>

      <div className="flex-1 overflow-y-auto rounded-2xl border border-border bg-bg-elevated p-2">
        {selectedProfileId && mods.length === 0 && (
          <p className="p-6 text-center text-sm text-zinc-600">No mods yet - add a .jar to get started.</p>
        )}
        {!selectedProfileId && (
          <p className="p-6 text-center text-sm text-zinc-600">Pick an instance above to see its mods.</p>
        )}
        {mods.map((mod) => (
          <motion.button
            key={mod.filename}
            layout
            onClick={() => onSelect(mod.filename)}
            className={`mb-1 flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${
              selected === mod.filename ? "bg-accent/15 text-accent" : "text-zinc-200 hover:bg-bg-card-hover"
            }`}
          >
            <span className="truncate">{mod.displayName}</span>
            <span className="ml-3 shrink-0 text-xs text-zinc-500">
              {mod.sizeKb} KB {!mod.enabled && "· disabled"}
            </span>
          </motion.button>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          onClick={onAdd}
          disabled={!selectedProfileId}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent disabled:opacity-40 transition-colors"
        >
          <Plus size={15} /> Add mod
        </button>
        <button
          onClick={onToggle}
          disabled={!selected}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent disabled:opacity-40 transition-colors"
        >
          {mods.find((m) => m.filename === selected)?.enabled === false ? (
            <ToggleLeft size={15} />
          ) : (
            <ToggleRight size={15} />
          )}
          Enable/disable
        </button>
        <button
          onClick={onRemove}
          disabled={!selected}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-red-400 hover:border-red-400 disabled:opacity-40 transition-colors"
        >
          <Trash2 size={15} /> Remove
        </button>
        <div className="flex-1" />
        <button
          onClick={onOpenFolder}
          disabled={!selectedProfileId}
          className="flex items-center gap-2 rounded-lg border border-border-light px-3.5 py-2 text-sm text-zinc-200 hover:border-accent hover:text-accent disabled:opacity-40 transition-colors"
        >
          <FolderTree size={15} /> Open instance folder
        </button>
      </div>
    </div>
  );
}

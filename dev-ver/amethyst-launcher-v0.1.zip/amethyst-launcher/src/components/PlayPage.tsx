import { Blocks, Palette, Settings as SettingsIcon } from "lucide-react";
import type { VersionEntry } from "../types/global";

interface PlayPageProps {
  selectedVersion: string;
  loader: "vanilla" | "fabric" | "forge";
  versions: VersionEntry[];
}

export default function PlayPage({ selectedVersion, loader, versions }: PlayPageProps) {
  const installedCount = versions.filter((v) => v.installed).length;

  return (
    <div className="flex h-full flex-col gap-6 p-8">
      <div>
        <h1 className="text-2xl font-bold text-zinc-50">Play</h1>
        <p className="text-sm text-zinc-500">
          Pick a version from the bar below, then hit Play.
        </p>
      </div>

      <div className="rounded-2xl border border-border bg-bg-card p-6">
        <p className="mb-1 text-xs font-medium text-zinc-500">Ready to launch</p>
        <p className="font-pixel text-lg text-accent">
          {selectedVersion || "no version selected"}
        </p>
        <p className="mt-2 text-sm capitalize text-zinc-400">{loader} loader</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-xl border border-border bg-bg-card p-4">
          <p className="text-2xl font-bold text-zinc-50">{installedCount}</p>
          <p className="text-xs text-zinc-500">Installed versions</p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-border bg-bg-card p-4 text-zinc-400">
          <Blocks size={16} />
          <p className="text-xs">Manage mods on the Mods tab</p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-border bg-bg-card p-4 text-zinc-400">
          <Palette size={16} />
          <p className="text-xs">Change your look on the Skins tab</p>
        </div>
      </div>

      <div className="flex-1" />

      <div className="flex items-center gap-2 text-xs text-zinc-600">
        <SettingsIcon size={13} />
        RAM, Java, and game directory live in Settings.
      </div>
    </div>
  );
}

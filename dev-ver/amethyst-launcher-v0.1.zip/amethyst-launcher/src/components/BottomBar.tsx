import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronUp, Loader2, RefreshCw, User } from "lucide-react";
import type { VersionEntry } from "../types/global";

interface BottomBarProps {
  versions: VersionEntry[];
  loadingVersions: boolean;
  selectedVersion: string;
  onSelectVersion: (id: string) => void;
  loader: "vanilla" | "fabric" | "forge";
  onSelectLoader: (loader: "vanilla" | "fabric" | "forge") => void;
  showSnapshots: boolean;
  showOldVersions: boolean;
  onToggleSnapshots: (value: boolean) => void;
  onToggleOldVersions: (value: boolean) => void;
  onRefresh: () => void;
  onPlay: () => void;
  busy: boolean;
  status: string;
  progress: { phase: string; task: number; total: number } | null;
  accountName: string;
  accountMode: string;
  onSwitchAccount: () => void;
}

export default function BottomBar({
  versions,
  loadingVersions,
  selectedVersion,
  onSelectVersion,
  loader,
  onSelectLoader,
  showSnapshots,
  showOldVersions,
  onToggleSnapshots,
  onToggleOldVersions,
  onRefresh,
  onPlay,
  busy,
  status,
  progress,
  accountName,
  accountMode,
  onSwitchAccount,
}: BottomBarProps) {
  const [versionPickerOpen, setVersionPickerOpen] = useState(false);
  const percent = progress && progress.total > 0 ? Math.min(100, (progress.task / progress.total) * 100) : 0;

  return (
    <div className="relative shrink-0">
      {/* Status / progress strip */}
      {(busy || status) && (
        <div className="border-t border-border bg-bg-sidebar px-4 py-1.5">
          <div className="flex items-center justify-between text-[11px] text-zinc-500">
            <span className="truncate">{status}</span>
            {progress && (
              <span className="ml-3 shrink-0 tabular-nums">
                {progress.phase} - {Math.round(percent)}%
              </span>
            )}
          </div>
          {progress && (
            <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-bg-elevated">
              <motion.div
                className="h-full rounded-full bg-accent"
                animate={{ width: `${percent}%` }}
                transition={{ ease: "easeOut", duration: 0.25 }}
              />
            </div>
          )}
        </div>
      )}

      {/* Main bar */}
      <div className="flex items-center justify-between gap-4 border-t border-border bg-bg-sidebar px-5 py-3">
        {/* Version picker */}
        <div className="relative">
          <button
            onClick={() => setVersionPickerOpen((v) => !v)}
            className="pixel-button flex items-center gap-2 rounded-lg bg-bg-card px-4 py-2.5 text-sm font-semibold text-accent hover:bg-bg-card-hover"
          >
            <span className="max-w-[180px] truncate">
              {selectedVersion || "Select version"}
            </span>
            <ChevronUp size={14} className={`transition-transform ${versionPickerOpen ? "" : "rotate-180"}`} />
          </button>

          <AnimatePresence>
            {versionPickerOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setVersionPickerOpen(false)} />
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.97 }}
                  transition={{ duration: 0.15 }}
                  className="absolute bottom-full left-0 z-50 mb-3 w-80 rounded-xl border border-border bg-bg-card p-4 shadow-2xl"
                >
                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">Loader</label>
                  <div className="mb-3 flex gap-2">
                    {(["vanilla", "fabric", "forge"] as const).map((l) => (
                      <button
                        key={l}
                        onClick={() => onSelectLoader(l)}
                        className={`flex-1 rounded-lg border py-1.5 text-xs font-medium capitalize transition-colors ${
                          loader === l
                            ? "border-accent bg-accent/15 text-accent"
                            : "border-border-light text-zinc-400 hover:text-zinc-100"
                        }`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>

                  <label className="mb-1.5 block text-xs font-medium text-zinc-400">Version</label>
                  <div className="mb-3 flex gap-2">
                    <select
                      value={selectedVersion}
                      onChange={(e) => onSelectVersion(e.target.value)}
                      className="flex-1 rounded-lg border border-border-light bg-bg-elevated px-2.5 py-1.5 text-xs text-zinc-100 outline-none focus:border-accent"
                    >
                      <option value="">Select a version...</option>
                      {versions.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.id} {v.installed ? "(installed)" : ""}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={onRefresh}
                      className="flex items-center justify-center rounded-lg border border-border-light px-2.5 text-zinc-300 hover:border-accent hover:text-accent transition-colors"
                    >
                      <RefreshCw size={13} className={loadingVersions ? "animate-spin" : ""} />
                    </button>
                  </div>

                  <div className="flex flex-col gap-1.5 text-xs text-zinc-400">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={showSnapshots}
                        onChange={(e) => onToggleSnapshots(e.target.checked)}
                        className="accent-[--color-accent]"
                      />
                      Show snapshots
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={showOldVersions}
                        onChange={(e) => onToggleOldVersions(e.target.checked)}
                        className="accent-[--color-accent]"
                      />
                      Show old alpha/beta
                    </label>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* Play button */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          disabled={busy || !selectedVersion}
          onClick={onPlay}
          className="pixel-button flex items-center gap-3 rounded-xl bg-accent px-10 py-3.5 text-black hover:bg-accent-hover disabled:cursor-not-allowed"
        >
          {busy && <Loader2 size={18} className="animate-spin" />}
          <span className="font-pixel text-[13px] tracking-wide">
            {busy ? "WORKING" : "PLAY"}
          </span>
        </motion.button>

        {/* Account switcher */}
        <button
          onClick={onSwitchAccount}
          className="pixel-button flex items-center gap-2 rounded-lg bg-bg-card px-4 py-2.5 text-sm font-semibold text-accent hover:bg-bg-card-hover"
        >
          <User size={15} />
          <span className="flex flex-col items-start leading-tight">
            <span className="max-w-[110px] truncate text-xs">{accountName}</span>
            <span className="text-[10px] font-normal text-zinc-500">{accountMode}</span>
          </span>
        </button>
      </div>
    </div>
  );
}

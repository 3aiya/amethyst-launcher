import { useEffect, useState, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import TitleBar from "./components/TitleBar";
import Sidebar, { type Page } from "./components/Sidebar";
import BottomBar from "./components/BottomBar";
import LogPanel from "./components/LogPanel";
import PlayPage from "./components/PlayPage";
import ModsPage from "./components/ModsPage";
import SkinsPage from "./components/SkinsPage";
import SettingsPage from "./components/SettingsPage";
import LoginModal from "./components/LoginModal";
import type { AmethystSettings, VersionEntry, ModEntry, ProgressPayload } from "./types/global";

const MAX_LOG_LINES = 500;

export default function App() {
  const [settings, setSettings] = useState<AmethystSettings | null>(null);
  const [page, setPage] = useState<Page>("play");
  const [loginOpen, setLoginOpen] = useState(false);
  const [logsOpen, setLogsOpen] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const [versions, setVersions] = useState<VersionEntry[]>([]);
  const [loadingVersions, setLoadingVersions] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState("");
  const [loader, setLoader] = useState<"vanilla" | "fabric" | "forge">("vanilla");

  const [mods, setMods] = useState<ModEntry[]>([]);
  const [selectedMod, setSelectedMod] = useState<string | null>(null);

  const [skinStatus, setSkinStatus] = useState("");

  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [progress, setProgress] = useState<ProgressPayload | null>(null);

  const refreshVersions = useCallback(async (showSnapshots: boolean, showOldVersions: boolean) => {
    setLoadingVersions(true);
    try {
      const list = await window.amethyst.versions.list(showSnapshots, showOldVersions);
      setVersions(list);
    } catch (e) {
      setStatus(e instanceof Error ? e.message : String(e));
    } finally {
      setLoadingVersions(false);
    }
  }, []);

  const refreshMods = useCallback(async () => {
    setMods(await window.amethyst.mods.list());
  }, []);

  useEffect(() => {
    (async () => {
      const s = await window.amethyst.settings.get();
      setSettings(s);
      setSelectedVersion(s.selectedVersion ?? "");
      setLoader(s.selectedLoader);
      await refreshVersions(s.showSnapshots, s.showOldVersions);
      await refreshMods();
      if (!s.account) setLoginOpen(true);
    })();
  }, [refreshVersions, refreshMods]);

  useEffect(() => {
    const offStatus = window.amethyst.play.onStatus(setStatus);
    const offProgress = window.amethyst.play.onProgress(setProgress);
    const offLog = window.amethyst.play.onLog((line) =>
      setLogs((prev) => [...prev, line].slice(-MAX_LOG_LINES))
    );
    const offClose = window.amethyst.play.onClose(() => {
      setStatus("Minecraft closed.");
      setBusy(false);
      setProgress(null);
    });
    return () => {
      offStatus();
      offProgress();
      offLog();
      offClose();
    };
  }, []);

  async function updateSettings(partial: Partial<AmethystSettings>) {
    const updated = await window.amethyst.settings.update(partial);
    setSettings(updated);
    return updated;
  }

  async function handleOfflineLogin(username: string) {
    const updated = await window.amethyst.auth.loginOffline(username);
    setSettings(updated);
  }

  async function handleMicrosoftLogin() {
    const updated = await window.amethyst.auth.loginMicrosoft();
    setSettings(updated);
  }

  async function handlePlay() {
    if (!selectedVersion) return;
    setBusy(true);
    setProgress(null);
    setStatus("Starting...");
    setLogs([]);
    await updateSettings({ selectedVersion, selectedLoader: loader });
    try {
      await window.amethyst.play.installAndLaunch(selectedVersion, loader);
    } catch (e) {
      setStatus(e instanceof Error ? e.message : String(e));
      setBusy(false);
      setProgress(null);
    }
  }

  async function handleAddMod() {
    const files = await window.amethyst.dialogs.pickFiles([{ name: "Jar files", extensions: ["jar"] }]);
    if (files.length === 0) return;
    setMods(await window.amethyst.mods.add(files));
  }

  async function handleRemoveMod() {
    if (!selectedMod) return;
    setMods(await window.amethyst.mods.remove(selectedMod));
    setSelectedMod(null);
  }

  async function handleToggleMod() {
    if (!selectedMod) return;
    const current = mods.find((m) => m.filename === selectedMod);
    if (!current) return;
    setMods(await window.amethyst.mods.toggle(selectedMod, !current.enabled));
  }

  async function handleUploadSkin(variant: "classic" | "slim") {
    const files = await window.amethyst.dialogs.pickFiles([{ name: "PNG images", extensions: ["png"] }]);
    if (files.length === 0) return;
    try {
      await window.amethyst.skins.upload(files[0], variant);
      setSkinStatus("Skin uploaded successfully.");
    } catch (e) {
      setSkinStatus(e instanceof Error ? e.message : String(e));
    }
  }

  async function handleResetSkin() {
    try {
      await window.amethyst.skins.reset();
      setSkinStatus("Skin reset to default.");
    } catch (e) {
      setSkinStatus(e instanceof Error ? e.message : String(e));
    }
  }

  async function handleBrowseGameDir() {
    const dir = await window.amethyst.dialogs.pickFolder(settings?.gameDirectory);
    if (dir) await updateSettings({ gameDirectory: dir });
  }

  async function handleBrowseJava() {
    const javaPath = await window.amethyst.dialogs.pickJava();
    if (javaPath) await updateSettings({ javaPath });
  }

  if (!settings) {
    return (
      <div className="flex h-screen items-center justify-center rounded-xl bg-bg text-zinc-500">
        Loading Amethyst Launcher...
      </div>
    );
  }

  const accountName = settings.account?.name ?? settings.offlineUsername;
  const accountMode = settings.authMode === "microsoft" ? "Microsoft" : "Offline";

  return (
    <div className="flex h-screen flex-col overflow-hidden rounded-xl bg-bg text-zinc-100">
      <TitleBar />
      <div className="relative flex flex-1 overflow-hidden">
        <Sidebar
          currentPage={page}
          onNavigate={setPage}
          logsOpen={logsOpen}
          onToggleLogs={() => setLogsOpen((v) => !v)}
        />

        <main className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              {page === "play" && (
                <PlayPage
                  versions={versions}
                  loadingVersions={loadingVersions}
                  selectedVersion={selectedVersion}
                  onSelectVersion={setSelectedVersion}
                  loader={loader}
                  onSelectLoader={setLoader}
                  showSnapshots={settings.showSnapshots}
                  showOldVersions={settings.showOldVersions}
                  onToggleSnapshots={(value) => {
                    updateSettings({ showSnapshots: value });
                    refreshVersions(value, settings.showOldVersions);
                  }}
                  onToggleOldVersions={(value) => {
                    updateSettings({ showOldVersions: value });
                    refreshVersions(settings.showSnapshots, value);
                  }}
                  onRefresh={() => refreshVersions(settings.showSnapshots, settings.showOldVersions)}
                />
              )}
              {page === "mods" && (
                <ModsPage
                  mods={mods}
                  selected={selectedMod}
                  onSelect={setSelectedMod}
                  onAdd={handleAddMod}
                  onRemove={handleRemoveMod}
                  onToggle={handleToggleMod}
                  onOpenFolder={() => window.amethyst.mods.openFolder()}
                />
              )}
              {page === "skins" && (
                <SkinsPage
                  isMicrosoftAccount={settings.authMode === "microsoft"}
                  onUpload={handleUploadSkin}
                  onReset={handleResetSkin}
                  statusMessage={skinStatus}
                />
              )}
              {page === "settings" && (
                <SettingsPage
                  settings={settings}
                  onSave={(partial) => updateSettings(partial)}
                  onBrowseGameDir={handleBrowseGameDir}
                  onBrowseJava={handleBrowseJava}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        <LogPanel open={logsOpen} logs={logs} onClose={() => setLogsOpen(false)} />
      </div>

      <BottomBar
        versions={versions}
        loadingVersions={loadingVersions}
        selectedVersion={selectedVersion}
        onSelectVersion={setSelectedVersion}
        onRefresh={() => refreshVersions(settings.showSnapshots, settings.showOldVersions)}
        onPlay={handlePlay}
        busy={busy}
        status={status}
        progress={progress}
        accountName={accountName}
        accountMode={accountMode}
        onSwitchAccount={() => setLoginOpen(true)}
      />

      <LoginModal
        open={loginOpen}
        defaultUsername={settings.offlineUsername}
        onClose={() => setLoginOpen(false)}
        onOfflineLogin={handleOfflineLogin}
        onMicrosoftLogin={handleMicrosoftLogin}
      />
    </div>
  );
}

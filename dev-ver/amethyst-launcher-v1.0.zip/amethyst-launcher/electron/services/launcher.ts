import path from "node:path";
import { Client } from "minecraft-launcher-core";
import type { AmethystSettings, ProgressPayload, LoaderType, QuickPlayTarget } from "../../shared/ipc-types";
import * as versions from "./versions";
import * as javaManager from "./javaManager";
import * as fabricInstaller from "./fabricInstaller";
import * as forgeInstaller from "./forgeInstaller";
import * as amethystPack from "./amethystPack";
import { toMclcUser } from "./auth";

export interface LaunchCallbacks {
  onStatus: (status: string) => void;
  onProgress: (progress: ProgressPayload) => void;
  onLog: (line: string) => void;
  onClose: (code: number) => void;
}

export async function installAndLaunch(
  settings: AmethystSettings,
  versionId: string,
  loader: LoaderType,
  callbacks: LaunchCallbacks,
  quickPlay?: QuickPlayTarget
): Promise<void> {
  if (!settings.account) throw new Error("No account signed in.");

  // Amethyst pack versions each get their own isolated profile folder (their
  // own mods/config/saves/servers.dat) instead of sharing the main game
  // directory - everything else (vanilla/fabric/forge) still shares it.
  const launchRoot =
    loader === "amethyst"
      ? amethystPack.getProfileDirectory(settings.gameDirectory, versionId)
      : settings.gameDirectory;

  let versionCustom: string | undefined;
  let minecraftJarOverride: string | undefined;
  let versionJsonOverride: string | undefined;
  let forgeInstallerPath: string | undefined;
  let effectiveVersionId = versionId;

  if (loader === "amethyst") {
    callbacks.onStatus("Installing the Amethyst pack...");
    const result = await amethystPack.installVersion(settings.gameDirectory, versionId, callbacks.onStatus);
    versionCustom = result.customId;
    effectiveVersionId = result.minecraftVersion;
    minecraftJarOverride = (await versions.ensureVanillaFiles(launchRoot, effectiveVersionId)).jarPath;
    versionJsonOverride = path.join(launchRoot, "versions", versionCustom, `${versionCustom}.json`);
  } else {
    callbacks.onStatus(`Preparing ${versionId}...`);
  }

  const clientJson = await versions.readVersionClientJson(launchRoot, effectiveVersionId).catch(() => null);
  const javaComponent = clientJson?.javaVersion?.component ?? "jre-legacy";

  callbacks.onStatus("Checking Java runtime...");
  const javaPath = await javaManager.ensureJavaFor(launchRoot, javaComponent, settings.javaPath, (p) =>
    callbacks.onProgress({ phase: "java", task: p.task, total: p.total })
  );

  if (loader === "fabric") {
    callbacks.onStatus("Downloading vanilla files Fabric depends on...");
    await versions.ensureVanillaFiles(launchRoot, versionId);

    callbacks.onStatus("Installing Fabric loader...");
    const result = await fabricInstaller.installFabric(launchRoot, versionId);
    versionCustom = result.customId;
    minecraftJarOverride = result.vanillaJarPath;
    versionJsonOverride = result.mergedJsonPath;
  } else if (loader === "forge") {
    callbacks.onStatus("Looking up matching Forge build...");
    const forgeVersion = await forgeInstaller.findRecommendedForgeVersion(versionId);
    if (!forgeVersion) throw new Error(`No Forge build found for ${versionId}.`);

    callbacks.onStatus(`Downloading Forge ${forgeVersion} installer...`);
    forgeInstallerPath = await forgeInstaller.downloadForgeInstaller(launchRoot, versionId, forgeVersion);
  }

  callbacks.onStatus("Launching Minecraft...");

  const extraArgs = settings.jvmArgs.trim() ? settings.jvmArgs.trim().split(/\s+/) : [];

  const client = new Client();
  client.on("progress", (p: any) =>
    callbacks.onProgress({ phase: p.type, task: p.task, total: p.total })
  );
  client.on("debug", (msg: string) => callbacks.onLog(`[debug] ${msg}`));
  client.on("data", (msg: string) => callbacks.onLog(msg));
  client.on("close", (code: number) => callbacks.onClose(code));

  await client.launch({
    root: launchRoot,
    version: { number: effectiveVersionId, type: "release", custom: versionCustom },
    memory: { min: `${settings.ramMinMb}M`, max: `${settings.ramMaxMb}M` },
    javaPath,
    customArgs: extraArgs,
    forge: forgeInstallerPath,
    window: { width: settings.windowWidth, height: settings.windowHeight },
    authorization: toMclcUser(settings.account) as any,
    overrides: {
      minecraftJar: minecraftJarOverride,
      versionJson: versionJsonOverride,
    },
    quickPlay: quickPlay ? { type: quickPlay.type, identifier: quickPlay.target } : undefined,
  });
}

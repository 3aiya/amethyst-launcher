/**
 * Amethyst modpack: our own curated pack, hosted as versioned zip files in a
 * shared Google Drive folder. Each version behaves exactly like a normal
 * Minecraft version in the Play tab's version picker - selecting one and
 * hitting Play downloads that version's zip (mods/config/servers.dat),
 * installs a matching Fabric base, and syncs everything into place.
 */

import fs from "node:fs";
import path from "node:path";
import AdmZip from "adm-zip";
import { GOOGLE_DRIVE_FOLDER_ID, GOOGLE_DRIVE_API_KEY } from "./amethystRemoteConfig";
import * as versions from "./versions";
import * as fabricInstaller from "./fabricInstaller";
import * as modsManager from "./modsManager";
import type { AmethystModpackVersion } from "../../shared/ipc-types";

const DRIVE_FILES_API = "https://www.googleapis.com/drive/v3/files";
const MODS_MARKER_FILE = "amethyst-pack-mods.json";
const INSTALLED_VERSION_FILE = "amethyst-pack-installed-version.txt";

interface DriveFile {
  id: string;
  name: string;
}

export class AmethystPackError extends Error {}

function isConfigured(): boolean {
  return (
    Boolean(GOOGLE_DRIVE_FOLDER_ID) &&
    Boolean(GOOGLE_DRIVE_API_KEY) &&
    !GOOGLE_DRIVE_FOLDER_ID.startsWith("PUT_YOUR") &&
    !GOOGLE_DRIVE_API_KEY.startsWith("PUT_YOUR")
  );
}

function versionFromFilename(filename: string): string {
  return filename.replace(/\.zip$/i, "");
}

/** Numeric, dot-separated version comparison (so "1.21.11" sorts after "1.21.9"). */
function compareVersions(a: string, b: string): number {
  const partsA = a.split(".").map((n) => parseInt(n, 10) || 0);
  const partsB = b.split(".").map((n) => parseInt(n, 10) || 0);
  const length = Math.max(partsA.length, partsB.length);
  for (let i = 0; i < length; i++) {
    const diff = (partsA[i] ?? 0) - (partsB[i] ?? 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function listDriveZipFiles(): Promise<DriveFile[]> {
  if (!isConfigured()) return [];

  const query = encodeURIComponent(`'${GOOGLE_DRIVE_FOLDER_ID}' in parents and trashed = false`);
  const url = `${DRIVE_FILES_API}?q=${query}&fields=files(id,name)&key=${GOOGLE_DRIVE_API_KEY}&pageSize=1000`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new AmethystPackError(`Failed to list Amethyst pack versions (${response.status}).`);
  }
  const data = (await response.json()) as { files?: DriveFile[] };
  return (data.files ?? []).filter((f) => f.name.toLowerCase().endsWith(".zip"));
}

function isVersionInstalled(gameDirectory: string, version: string): boolean {
  const cachedZip = path.join(gameDirectory, "amethyst-cache", `${version}.zip`);
  return fs.existsSync(cachedZip);
}

export async function listAvailableVersions(gameDirectory: string): Promise<AmethystModpackVersion[]> {
  const files = await listDriveZipFiles();
  return files
    .map((f) => versionFromFilename(f.name))
    .sort(compareVersions)
    .reverse()
    .map((version) => ({
      version,
      minecraftVersion: version,
      modCount: 0,
      installed: isVersionInstalled(gameDirectory, version),
    }));
}

export function getInstalledVersion(gameDirectory: string): string | null {
  try {
    return fs.readFileSync(path.join(gameDirectory, INSTALLED_VERSION_FILE), "utf-8").trim();
  } catch {
    return null;
  }
}

async function downloadDriveFile(fileId: string, destination: string): Promise<void> {
  const url = `${DRIVE_FILES_API}/${fileId}?alt=media&key=${GOOGLE_DRIVE_API_KEY}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new AmethystPackError(`Failed to download Amethyst pack (${response.status}).`);
  }
  fs.writeFileSync(destination, Buffer.from(await response.arrayBuffer()));
}

function copyRecursive(source: string, destination: string): void {
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      copyRecursive(from, to);
    } else {
      fs.copyFileSync(from, to);
    }
  }
}

/** Copies the pack's mods in, and removes whatever the pack put there on the
 * previous sync but no longer ships - without touching mods the person added
 * themselves. */
function syncMods(gameDirectory: string, sourceModsDir: string): void {
  const markerPath = path.join(gameDirectory, MODS_MARKER_FILE);
  const previouslyManaged = new Set<string>();
  try {
    (JSON.parse(fs.readFileSync(markerPath, "utf-8")) as string[]).forEach((f) => previouslyManaged.add(f));
  } catch {
    /* first sync - no marker yet */
  }

  const nowManaged: string[] = [];
  if (fs.existsSync(sourceModsDir)) {
    for (const filename of fs.readdirSync(sourceModsDir)) {
      if (!filename.toLowerCase().endsWith(".jar")) continue;
      modsManager.addMod(gameDirectory, path.join(sourceModsDir, filename));
      nowManaged.push(filename);
      previouslyManaged.delete(filename);
    }
  }

  for (const stale of previouslyManaged) {
    modsManager.removeMod(gameDirectory, stale);
  }

  fs.writeFileSync(markerPath, JSON.stringify(nowManaged, null, 2));
}

export interface AmethystInstallResult {
  customId: string;
  minecraftVersion: string;
}

export async function installVersion(
  gameDirectory: string,
  version: string,
  onStatus?: (status: string) => void
): Promise<AmethystInstallResult> {
  if (!isConfigured()) {
    throw new AmethystPackError(
      "Amethyst pack hosting isn't configured yet. Set GOOGLE_DRIVE_FOLDER_ID and " +
        "GOOGLE_DRIVE_API_KEY in electron/services/amethystRemoteConfig.ts."
    );
  }

  onStatus?.(`Looking up Amethyst pack ${version}...`);
  const files = await listDriveZipFiles();
  const match = files.find((f) => versionFromFilename(f.name) === version);
  if (!match) throw new AmethystPackError(`Amethyst pack version ${version} was not found.`);

  const cacheDir = path.join(gameDirectory, "amethyst-cache");
  fs.mkdirSync(cacheDir, { recursive: true });
  const zipPath = path.join(cacheDir, `${version}.zip`);

  if (!fs.existsSync(zipPath)) {
    onStatus?.(`Downloading Amethyst pack ${version}...`);
    await downloadDriveFile(match.id, zipPath);
  }

  onStatus?.("Extracting Amethyst pack...");
  const extractDir = path.join(cacheDir, `${version}-extracted`);
  fs.rmSync(extractDir, { recursive: true, force: true });
  new AdmZip(zipPath).extractAllTo(extractDir, true);

  // The zip is named after the Minecraft version it targets (e.g. "1.20.6.zip").
  const minecraftVersion = version;

  onStatus?.(`Preparing Fabric base for ${minecraftVersion}...`);
  await versions.ensureVanillaFiles(gameDirectory, minecraftVersion);
  const { customId } = await fabricInstaller.installFabric(gameDirectory, minecraftVersion);

  const sourceMods = path.join(extractDir, "mods");
  onStatus?.("Syncing mods...");
  syncMods(gameDirectory, sourceMods);

  const sourceConfig = path.join(extractDir, "config");
  if (fs.existsSync(sourceConfig)) {
    onStatus?.("Syncing config...");
    copyRecursive(sourceConfig, path.join(gameDirectory, "config"));
  }

  const sourceServersDat = path.join(extractDir, "servers.dat");
  if (fs.existsSync(sourceServersDat)) {
    onStatus?.("Installing server list...");
    fs.copyFileSync(sourceServersDat, path.join(gameDirectory, "servers.dat"));
  }

  fs.writeFileSync(path.join(gameDirectory, INSTALLED_VERSION_FILE), version);

  return { customId, minecraftVersion };
}

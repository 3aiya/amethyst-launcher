import { ipcMain, BrowserWindow, dialog, shell } from "electron";
import path from "node:path";
import crypto from "node:crypto";
import * as db from "./db";
import * as authService from "./services/auth";
import * as versionsService from "./services/versions";
import * as modsService from "./services/modsManager";
import * as skinService from "./services/skinManager";
import * as launcherService from "./services/launcher";
import * as discordRpc from "./services/discordRpc";
import * as serverPing from "./services/serverPing";
import * as worldsService from "./services/worlds";
import * as amethystPackService from "./services/amethystPack";
import * as profilesService from "./services/profiles";
import type { LoaderType, ServerConfig, QuickPlayTarget } from "../shared/ipc-types";

export function registerIpcHandlers(mainWindow: BrowserWindow): void {
  // ---- Settings / account -------------------------------------------------
  ipcMain.handle("settings:get", () => db.getSettings());

  ipcMain.handle("settings:update", (_e, partial) => db.updateSettings(partial));

  ipcMain.handle("auth:offline-login", (_e, username: string) => {
    const account = authService.offlineLogin(username);
    return db.updateSettings({ authMode: "offline", offlineUsername: account.name, account });
  });

  ipcMain.handle("auth:microsoft-login", async () => {
    const account = await authService.loginWithMicrosoft();
    return db.updateSettings({ authMode: "microsoft", account });
  });

  // ---- Versions -------------------------------------------------------------
  ipcMain.handle(
    "versions:list",
    async (_e, showSnapshots: boolean, showOldVersions: boolean) => {
      const settings = db.getSettings();
      return versionsService.listAvailableVersions(settings.gameDirectory, showSnapshots, showOldVersions);
    }
  );

  // ---- Play / install / launch ----------------------------------------------
  ipcMain.handle(
    "play:install-and-launch",
    async (_e, versionId: string, loader: LoaderType, quickPlay?: QuickPlayTarget) => {
      const settings = db.updateSettings({ selectedVersion: versionId, selectedLoader: loader });

      await launcherService.installAndLaunch(
        settings,
        versionId,
        loader,
        {
          onStatus: (status) => mainWindow.webContents.send("play:status", status),
          onProgress: (progress) => mainWindow.webContents.send("play:progress", progress),
          onLog: (line) => mainWindow.webContents.send("play:log", line),
          onClose: (code) => {
            discordRpc.setIdlePresence();
            mainWindow.webContents.send("play:close", code);
          },
        },
        quickPlay
      );

      discordRpc.setPlayingPresence(versionId, loader);
    }
  );

  // ---- Servers -------------------------------------------------------------
  ipcMain.handle("servers:list", () => db.getSettings().servers);

  ipcMain.handle("servers:ping", (_e, address: string) => serverPing.pingServer(address));

  ipcMain.handle(
    "servers:add",
    (_e, entry: Omit<ServerConfig, "id" | "isPrimary">) => {
      const settings = db.getSettings();
      const newServer: ServerConfig = { ...entry, id: crypto.randomUUID(), isPrimary: false };
      return db.updateSettings({ servers: [...settings.servers, newServer] }).servers;
    }
  );

  ipcMain.handle("servers:remove", (_e, id: string) => {
    const settings = db.getSettings();
    return db.updateSettings({ servers: settings.servers.filter((s) => s.id !== id) }).servers;
  });

  // ---- Worlds -------------------------------------------------------------
  ipcMain.handle("worlds:list", () => worldsService.listWorlds(db.getSettings().gameDirectory));

  // ---- Amethyst pack (custom loader, versions hosted on Google Drive) -----
  ipcMain.handle("amethystPack:listVersions", () => {
    const settings = db.getSettings();
    return amethystPackService.listAvailableVersions(settings.gameDirectory);
  });

  // ---- Profiles / instances -------------------------------------------------
  ipcMain.handle("profiles:list", () => profilesService.listProfiles(db.getSettings().gameDirectory));

  ipcMain.handle("profiles:rename", (_e, id: string, name: string) => profilesService.renameProfile(id, name));

  ipcMain.handle("profiles:delete", (_e, id: string) =>
    profilesService.deleteProfile(db.getSettings().gameDirectory, id)
  );

  // ---- Mods -------------------------------------------------------------
  ipcMain.handle("mods:list", () => modsService.listMods(db.getSettings().gameDirectory));

  ipcMain.handle("mods:add", (_e, filePaths: string[]) => {
    const gameDirectory = db.getSettings().gameDirectory;
    filePaths.forEach((p) => modsService.addMod(gameDirectory, p));
    return modsService.listMods(gameDirectory);
  });

  ipcMain.handle("mods:remove", (_e, filename: string) => {
    const gameDirectory = db.getSettings().gameDirectory;
    modsService.removeMod(gameDirectory, filename);
    return modsService.listMods(gameDirectory);
  });

  ipcMain.handle("mods:toggle", (_e, filename: string, enabled: boolean) => {
    const gameDirectory = db.getSettings().gameDirectory;
    modsService.setModEnabled(gameDirectory, filename, enabled);
    return modsService.listMods(gameDirectory);
  });

  ipcMain.handle("mods:open-folder", () => {
    const gameDirectory = db.getSettings().gameDirectory;
    shell.openPath(modsService.modsDirectory(gameDirectory));
  });

  // ---- Skins -------------------------------------------------------------
  ipcMain.handle("skins:upload", async (_e, filePath: string, variant: "classic" | "slim") => {
    const account = db.getSettings().account;
    if (!account || account.authMode !== "microsoft") {
      throw new Error("Sign in with a Microsoft account first.");
    }
    await skinService.setSkinFromFile(account.accessToken, filePath, variant);
  });

  ipcMain.handle("skins:reset", async () => {
    const account = db.getSettings().account;
    if (!account || account.authMode !== "microsoft") {
      throw new Error("Sign in with a Microsoft account first.");
    }
    await skinService.resetSkin(account.accessToken);
  });

  // ---- File / folder dialogs -------------------------------------------------
  ipcMain.handle("dialog:pick-files", async (_e, filters?: { name: string; extensions: string[] }[]) => {
    const result = await dialog.showOpenDialog(mainWindow, { properties: ["openFile", "multiSelections"], filters });
    return result.canceled ? [] : result.filePaths;
  });

  ipcMain.handle("dialog:pick-folder", async (_e, defaultPath?: string) => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ["openDirectory"],
      defaultPath,
    });
    return result.canceled ? null : result.filePaths[0];
  });

  ipcMain.handle("dialog:pick-java", async () => {
    const result = await dialog.showOpenDialog(mainWindow, { properties: ["openFile"] });
    return result.canceled ? null : result.filePaths[0];
  });

  // ---- Window controls -------------------------------------------------------
  ipcMain.on("window:minimize", () => mainWindow.minimize());
  ipcMain.on("window:maximize", () => {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  });
  ipcMain.on("window:close", () => mainWindow.close());
}

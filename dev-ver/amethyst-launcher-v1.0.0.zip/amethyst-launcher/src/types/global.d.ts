import type {
  AmethystSettings,
  Account,
  VersionEntry,
  ModEntry,
  ProgressPayload,
  SkinVariant,
  ServerConfig,
  ServerPingResult,
  WorldEntry,
  AmethystModpackVersion,
  LoaderType,
  QuickPlayTarget,
  Profile,
} from "../../shared/ipc-types";

export interface AmethystApi {
  settings: {
    get: () => Promise<AmethystSettings>;
    update: (partial: Partial<AmethystSettings>) => Promise<AmethystSettings>;
  };
  auth: {
    loginOffline: (username: string) => Promise<AmethystSettings>;
    loginMicrosoft: () => Promise<AmethystSettings>;
  };
  versions: {
    list: (showSnapshots: boolean, showOldVersions: boolean) => Promise<VersionEntry[]>;
  };
  servers: {
    list: () => Promise<ServerConfig[]>;
    ping: (address: string) => Promise<ServerPingResult>;
    add: (entry: Omit<ServerConfig, "id" | "isPrimary">) => Promise<ServerConfig[]>;
    remove: (id: string) => Promise<ServerConfig[]>;
  };
  worlds: {
    list: () => Promise<WorldEntry[]>;
  };
  amethystPack: {
    listVersions: () => Promise<AmethystModpackVersion[]>;
  };
  profiles: {
    list: () => Promise<Profile[]>;
    rename: (id: string, name: string) => Promise<Profile[]>;
    remove: (id: string) => Promise<Profile[]>;
  };
  play: {
    installAndLaunch: (versionId: string, loader: string, quickPlay?: QuickPlayTarget) => Promise<void>;
    onStatus: (cb: (status: string) => void) => () => void;
    onProgress: (cb: (progress: ProgressPayload) => void) => () => void;
    onLog: (cb: (line: string) => void) => () => void;
    onClose: (cb: (code: number) => void) => () => void;
  };
  mods: {
    list: () => Promise<ModEntry[]>;
    add: (filePaths: string[]) => Promise<ModEntry[]>;
    remove: (filename: string) => Promise<ModEntry[]>;
    toggle: (filename: string, enabled: boolean) => Promise<ModEntry[]>;
    openFolder: () => Promise<void>;
  };
  skins: {
    upload: (filePath: string, variant: SkinVariant) => Promise<void>;
    reset: () => Promise<void>;
  };
  dialogs: {
    pickFiles: (filters?: { name: string; extensions: string[] }[]) => Promise<string[]>;
    pickFolder: (defaultPath?: string) => Promise<string | null>;
    pickJava: () => Promise<string | null>;
  };
  window: {
    minimize: () => void;
    maximize: () => void;
    close: () => void;
  };
}

declare global {
  interface Window {
    amethyst: AmethystApi;
  }
}

export type {
  AmethystSettings,
  Account,
  VersionEntry,
  ModEntry,
  ProgressPayload,
  SkinVariant,
  ServerConfig,
  ServerPingResult,
  WorldEntry,
  AmethystModpackVersion,
  LoaderType,
  QuickPlayTarget,
  Profile,
};
